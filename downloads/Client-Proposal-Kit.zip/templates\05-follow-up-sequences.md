# Follow-Up Sequences

The proposal is not the close — the follow-up is. Most deals are won or lost in the follow-up. These templates cover every scenario from "they haven't responded" to "they said no."

---

## Sequence 1: Post-Proposal Follow-Up

Use this sequence after sending a proposal. Adjust timing based on your sales cycle.

---

### Day 1: Proposal Sent — Confirmation

Send immediately after the proposal.

> Subject: [Project Name] proposal — just sent
>
> Hi [Name],
>
> I just sent over the proposal for [project/engagement name]. It covers [1-sentence summary of what's in it].
>
> Take your time reviewing it. I'm available [tomorrow / this week] if you'd like to walk through it together — sometimes it's easier to discuss in person than over email.
>
> Talk soon.
>
> [Your Name]

---

### Day 3: Check-In — Did You Receive It?

> Subject: Re: [Project Name] proposal
>
> Hi [Name],
>
> Just wanted to make sure the proposal came through okay and see if anything jumped out that you'd like to discuss. I know things get busy — happy to hop on a quick call if that's easier than going back and forth over email.
>
> [Your Name]

---

### Day 7: Add Value — Don't Just "Check In"

> Subject: Thought of you — [relevant resource or insight]
>
> Hi [Name],
>
> I came across [article / example / case study / data point] related to what we discussed about [their specific challenge]. Thought you might find it useful regardless of whether we work together:
>
> [Link or brief summary]
>
> No pressure on the proposal — just wanted to share while it was top of mind. Let me know if you have any questions.
>
> [Your Name]

---

### Day 14: Direct — Ask for a Decision

> Subject: [Project Name] — where are we?
>
> Hi [Name],
>
> I wanted to follow up on the proposal from [date]. I want to respect your time, so I'll be direct: are you still considering this, or has the timing or priority changed?
>
> Either answer is completely fine — I'd just rather know where things stand so I can plan accordingly on my end.
>
> If you're still interested but need to adjust the scope, timeline, or investment, I'm open to that conversation.
>
> [Your Name]

---

### Day 21: Final Follow-Up — Create a Graceful Exit

> Subject: Closing the loop on [Project Name]
>
> Hi [Name],
>
> I've followed up a few times on the [project name] proposal and haven't heard back, so I want to be respectful of your inbox.
>
> I'll assume the timing isn't right for now and close this out on my end. No hard feelings at all — priorities shift, and I get it.
>
> If things change down the road, my door is always open. You know where to find me.
>
> Wishing you and [company name] all the best.
>
> [Your Name]

---

## Sequence 2: Post-Meeting / Post-Discovery Follow-Up

Use this between the discovery call and the proposal.

---

### Same Day: Discovery Summary

Send within 2-4 hours of the discovery call.

> Subject: Great conversation — here's what I heard
>
> Hi [Name],
>
> Thanks for the time today. Here's a summary of what we discussed:
>
> **The situation:**
> - [Key challenge 1]
> - [Key challenge 2]
> - [Impact you uncovered]
>
> **What you're looking for:**
> - [Desired outcome in their words]
> - [Timeline mentioned]
>
> **Next steps:**
> - I'll have a proposal to you by [date]
> - [Any action items on their end — assets to send, people to loop in]
>
> Did I capture that accurately? Let me know if I missed anything.
>
> [Your Name]

---

### Proposal Delivery Day: Send With Context

> Subject: Your [Project Name] proposal is ready
>
> Hi [Name],
>
> Attached is the proposal we discussed. Here's the quick version:
>
> - **What:** [1-sentence scope summary]
> - **Timeline:** [Start date] to [End date]
> - **Investment:** [Price or price range]
>
> I've included [two/three] options so you can choose the level that fits best. I've noted my recommendation and why.
>
> I'd love to walk you through it live — would [day] at [time] work for a 15-minute call? It's always easier to discuss together than over email.
>
> [Your Name]

---

## Sequence 3: They Said "Not Right Now"

Don't disappear. Stay useful and top of mind so you're the first call when timing is right.

---

### Immediate: Acknowledge and Leave the Door Open

> Hi [Name],
>
> Totally understand — timing is everything, and I'd rather we work together when it's the right moment than force something that doesn't fit.
>
> I'll check in [next quarter / in a few months] to see how things are going. In the meantime, if anything changes or you just want to bounce an idea around, don't hesitate to reach out.
>
> [Your Name]

---

### 90 Days Later: Reconnect With Value

> Subject: [Name] — quick thought for you
>
> Hi [Name],
>
> Hope [company] is going well. We talked back in [month] about [their challenge], and I've been working on something similar with another client that made me think of you.
>
> [1-2 sentences about a relevant insight, result, or resource — not a pitch]
>
> No agenda here — just staying in touch. If [the original problem] is still on your radar, I'd love to pick the conversation back up.
>
> [Your Name]

---

## Sequence 4: They Said "No" — Went With Someone Else

---

### Immediate: Be Gracious

> Hi [Name],
>
> I appreciate you letting me know — and for being straightforward about it. I respect that.
>
> I hope [competitor/other provider] does great work for you. If for any reason things don't go as planned, or if a different need comes up in the future, I'm always just an email away.
>
> Wishing you and [company] the best.
>
> [Your Name]

---

### 6 Months Later: Check In

> Subject: How did [project] turn out?
>
> Hi [Name],
>
> It's been about 6 months since we spoke about [project]. I'm genuinely curious — how did things go with [the direction you chose]?
>
> If you're happy with the results, that's great. If there's a gap or a next phase you're thinking about, I'd enjoy catching up.
>
> Either way, no pitch — just checking in.
>
> [Your Name]

---

## Sequence 5: Client Went Silent Mid-Project

For when a current client stops responding and you need deliverables or approvals to continue.

---

### Day 3: Gentle Nudge

> Hi [Name],
>
> Just checking in — I'm waiting on [specific item: feedback on the draft / the assets we discussed / your approval on the mockup] to keep things moving on schedule.
>
> No rush if you need a few more days, but wanted to flag it so we stay on track for the [milestone] deadline on [date].
>
> [Your Name]

---

### Day 7: Flag the Impact

> Hi [Name],
>
> Following up on [item] — I want to make sure we stay on timeline. The [milestone] was scheduled for [date], and without [what you need], I'll need to push that back.
>
> If things have gotten busy on your end, no problem — just let me know your availability and we can adjust the schedule.
>
> [Your Name]

---

### Day 14: Formal Pause Notice

> Subject: [Project Name] — schedule update
>
> Hi [Name],
>
> I've reached out a couple of times about [what you need] and haven't been able to connect. I completely understand that things come up — no judgment.
>
> To keep things clean on both sides, I'm going to pause active work on [project name] as of [date] until we're able to reconnect and realign on the timeline. This doesn't affect our agreement — we'll pick up right where we left off.
>
> When you're ready, just reply to this email and I'll get us back on the calendar within [48 hours].
>
> [Your Name]

---

## Tips

- **"Just checking in" is the worst follow-up in existence.** Every follow-up should either add value, ask a specific question, or create clarity. If you can't do one of those three things, don't send it.
- **Follow up more than you think you should.** Most salespeople give up after 1-2 follow-ups. Most deals close after 5-7 touches. The difference between persistent and annoying is whether you're adding value each time.
- **Vary the channel.** If email isn't working, try a phone call or LinkedIn message. Some people just don't live in their inbox.
- **Set a follow-up date before you hang up.** "I'll have the proposal to you by Thursday" gives you a natural reason to reach out. "I'll be in touch" gives you nothing.
- **The graceful exit works.** When you give someone an out ("I'll close this out and stop following up"), they often reply. Giving up the chase removes pressure, and people respond to that.
- **Track everything.** Use a CRM, a spreadsheet, or a Notion board — but track every prospect, every touchpoint, and every next step. Your memory is not a CRM.
