# Quick-Start Guide

You just bought the Client Proposal Kit. Here's how to win your next deal with it.

---

## Have a Proposal to Write Right Now? Start Here

1. **Run discovery first** — Open `templates/01-discovery-questionnaire.md` and use the framework for your next call. Fill out the post-call notes template immediately after.

2. **Write the proposal** — Open `templates/02-proposal.md`, pick the template that fits (service, project, or retainer), and fill it in using your discovery notes. Or skip the template and use `prompts/proposal-writer.md → Prompt 1` to have AI draft it from your notes.

3. **Set your pricing** — Use `templates/04-pricing-guide.md` for frameworks (cost-plus, value-based, or tiered). Present 2 options, recommend one.

4. **Send and follow up** — Use `templates/05-follow-up-sequences.md` for a proven 4-email sequence so the proposal doesn't die in their inbox.

That's the core workflow. Everything else in the kit supports and strengthens this loop.

---

## Building Your Sales System? Work Through This

If you're setting up a repeatable proposal process (not just writing one proposal), go in this order:

1. **Templates first** — Customize the proposal and SOW templates for your business. Replace the bracketed text with your defaults so future proposals start 80% done.

2. **Pricing second** — Use the pricing guide to establish your rate sheet, standard tiers, and how you talk about money. Decide this once so you're not reinventing it every proposal.

3. **Follow-up sequences third** — Set up your post-proposal cadence. Save the email templates somewhere you can grab them fast (email drafts, Notion, CRM templates).

4. **Case studies last** — After you close a few deals, build your proof. Use `templates/06-case-study.md` and the testimonial collection email to gather social proof.

---

## What's in Each File

| File | What it is | When you need it |
|------|-----------|-----------------|
| `01-discovery-questionnaire.md` | 3 discovery frameworks + post-call notes template | Before every sales conversation |
| `02-proposal.md` | 3 proposal templates (service, project, retainer) | After discovery, when you're ready to propose |
| `03-scope-of-work.md` | 2 SOW templates (project + retainer) | After the proposal is accepted |
| `04-pricing-guide.md` | Rate sheet template, tiered pricing, 3 pricing frameworks | When setting rates or building pricing into a proposal |
| `05-follow-up-sequences.md` | 5 follow-up sequences covering every scenario | After sending a proposal or losing a prospect |
| `06-case-study.md` | Case study templates + testimonial collection email | After completing a project you're proud of |
| `prompts/proposal-writer.md` | 8 AI prompts for writing and improving proposals | When drafting proposals, SOWs, or case studies |
| `prompts/discovery-coach.md` | 7 AI prompts for sales prep and objection handling | Before calls, when qualifying leads, handling pushback |
| `prompts/client-communications.md` | 8 AI prompts for the full client lifecycle | Welcoming, updating, scope creep, referrals, win-backs |

---

## Using the AI Prompts

The prompt packs work with any AI tool — ChatGPT, Claude, Gemini, or whatever you prefer.

**How to use them:**
1. Open the prompt file
2. Copy the prompt you need
3. Replace the bracketed `[text]` with your details
4. Paste into your AI tool
5. Edit the output — AI gives you 80%, your judgment finishes the job

**Best prompts to start with:**
- `proposal-writer.md → Prompt 1` (Generate from Discovery Notes) — fastest path from call to proposal
- `discovery-coach.md → Prompt 1` (Prepare for a Call) — never walk into a discovery unprepared
- `proposal-writer.md → Prompt 4` (Tiered Pricing) — creates good/better/best options with pricing logic

---

## Importing into Your Tools

### Google Docs / Word
Copy the template content and paste into a new document. Save it as "[Your Company] Proposal Template" so it's ready for the next deal.

### Notion
1. Create a new page
2. Paste directly — Notion converts markdown automatically
3. Consider creating a Notion database for proposals: one entry per prospect with status tracking (Discovery → Proposed → Negotiating → Won/Lost)

### CRM (HubSpot, Salesforce, Pipedrive, etc.)
- Save email templates from the follow-up sequences as CRM email templates
- Set up automated follow-up sequences using the timing from `05-follow-up-sequences.md`
- Use the discovery questionnaire fields as custom properties on your deal records

### Proposal Software (PandaDoc, Proposify, Better Proposals)
- Use these templates as the content foundation and import into your proposal tool's template builder
- The tiered pricing format maps directly to most proposal software's pricing table components

---

## The Sales Process at a Glance

| Stage | What happens | Kit resources |
|-------|-------------|--------------|
| **Lead comes in** | Qualify — is this worth a call? | `discovery-coach.md → Prompt 4` |
| **Discovery** | Run the call, take notes | `01-discovery-questionnaire.md` |
| **Post-discovery** | Send summary, start proposal | `discovery-coach.md → Prompt 3` |
| **Proposal** | Write, price, send | `02-proposal.md`, `04-pricing-guide.md` |
| **Follow-up** | Stay in front of the prospect | `05-follow-up-sequences.md` |
| **Negotiation** | Handle objections and pricing | `discovery-coach.md → Prompt 2`, `proposal-writer.md → Prompt 8` |
| **Close** | Get the signature | `03-scope-of-work.md` |
| **Delivery** | Manage the engagement | `client-communications.md` |
| **Wrap-up** | Close the loop, get proof | `06-case-study.md`, `client-communications.md → Prompt 5` |
| **Referral** | Turn one client into the next | `client-communications.md → Prompt 7` |

---

## Common Mistakes to Avoid

1. **Writing the proposal before doing discovery.** A proposal that isn't based on a real conversation is a brochure. Brochures don't close deals.

2. **Leading with your credentials.** The client doesn't care about your bio until they believe you understand their problem. Problem first, always.

3. **Presenting one option.** One option is a take-it-or-leave-it. Two options give the client agency and increase close rates.

4. **Not following up.** Most proposals don't close themselves. The follow-up sequence is where deals are actually won. Use it.

5. **Pricing by the hour instead of the outcome.** Your client is buying a result, not your time. Frame the investment around what they get, not what it costs you to deliver.
