# Case Study & Social Proof Templates

Case studies are proposals for future clients written in the voice of past clients. They answer the only question a prospect actually has: "Has this worked for someone like me?"

---

## Template 1: Full Case Study — Problem / Solution / Results

The classic structure. Use this for your website, sales materials, or as a leave-behind after a discovery call.

---

### [Headline — Lead with the result, not the client name]

> Example: "How a 12-person agency cut onboarding time from 3 weeks to 4 days"

---

**Client:** [Company Name] *(or "A [industry] company" if they prefer anonymity)*
**Industry:** [Industry]
**Company size:** [X employees / $X revenue]
**Service provided:** [What you did]
**Timeline:** [How long the engagement lasted]

---

#### The Challenge

[2-3 paragraphs describing the client's situation before they hired you. Use specific details — numbers, pain points, consequences. Write it so a similar prospect reads this and thinks "that's exactly what we're going through."]

> Questions to answer:
> - What was the problem?
> - How long had it existed?
> - What had they tried before?
> - What was the cost of inaction?

---

#### The Solution

[2-3 paragraphs describing what you did. Focus on your approach and reasoning, not just a list of tasks. Help the reader understand *why* you made the choices you made.]

> Questions to answer:
> - What was your approach?
> - Why did you choose this path over alternatives?
> - What did the process look like from the client's perspective?
> - Were there any surprises or pivots along the way?

---

#### The Results

[Lead with hard numbers. Then follow with qualitative outcomes.]

**By the numbers:**

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| [Key metric 1] | [Value] | [Value] | [+/- X%] |
| [Key metric 2] | [Value] | [Value] | [+/- X%] |
| [Key metric 3] | [Value] | [Value] | [+/- X%] |

**What changed:**

- [Qualitative outcome 1 — e.g., "The CEO stopped being the bottleneck for every hiring decision"]
- [Qualitative outcome 2 — e.g., "New hires became productive in days instead of weeks"]
- [Qualitative outcome 3 — e.g., "The team could take on 30% more clients without adding headcount"]

---

#### Client Testimonial

> "[Direct quote from the client about the experience and results. Use their exact words — don't polish it into corporate speak. Imperfect quotes feel more real.]"
>
> — [Name], [Title], [Company]

---

## Template 2: Short Case Study — One-Page Format

Use this when you need something concise for a proposal appendix, pitch deck, or social media.

---

### [Client/Industry] — [One-line result]

**Challenge:** [1-2 sentences — what was broken]

**What we did:** [1-2 sentences — your approach]

**Results:**
- [Metric 1 — the big number]
- [Metric 2]
- [Metric 3]

**Client said:** "[One-sentence testimonial]" — [Name], [Title]

---

## Template 3: Testimonial Collection Email

Send this to clients you've done good work for. Most happy clients are willing to give a testimonial — they just need to be asked and given an easy framework.

---

> Subject: Quick favor — would mean a lot
>
> Hi [Name],
>
> I really enjoyed working with you on [project], and I'm glad it [reference a specific result or positive outcome].
>
> I'm putting together some case studies and client stories for my website, and I'd love to include our work together. Would you be open to answering a few quick questions? It shouldn't take more than 5-10 minutes.
>
> Here's what I'm looking for:
>
> 1. What was the situation before we worked together? What prompted you to look for help?
> 2. What was the experience of working with me/us like?
> 3. What results have you seen? (Even rough numbers or directional outcomes are great.)
> 4. Would you recommend [my company] to someone in a similar situation? Why?
>
> Feel free to reply in a few bullet points — I don't need polished paragraphs. I'll draft something up and send it to you for approval before anything goes public.
>
> No pressure at all if the timing doesn't work. Either way, I appreciate the trust you placed in me.
>
> [Your Name]

---

### Follow-Up if No Response (7 days later)

> Hi [Name],
>
> Just bumping this in case it got buried. Totally understand if you're swamped — happy to keep it super simple.
>
> If writing feels like too much, I could also send you 3 questions to answer on a quick call (10 min max). I'll do all the writing afterward.
>
> [Your Name]

---

## Template 4: Client Reference List

Keep this updated and ready to share when a prospect asks, "Can I talk to one of your past clients?"

---

### Client References

*Available upon request during the proposal review process.*

| Client | Contact | Project | Highlights | Best for prospects who... |
|--------|---------|---------|------------|--------------------------|
| [Company 1] | [Name, Title, email/phone] | [Brief description] | [Key result] | [...are in the same industry] |
| [Company 2] | [Name, Title, email/phone] | [Brief description] | [Key result] | [...have a similar challenge] |
| [Company 3] | [Name, Title, email/phone] | [Brief description] | [Key result] | [...are a similar size] |

**Before sharing:**
- Always ask the reference for permission before sharing their contact info with a prospect
- Brief them on who will be calling and what the prospect cares about
- Follow up with a thank you after the reference call

---

## Tips

- **Results first, process second.** Nobody reads a case study for the methodology. They read it to see if you can deliver results. Lead with the numbers.
- **Be specific.** "Increased revenue" is forgettable. "Increased monthly recurring revenue by 40% in 90 days" is a case study people share.
- **One case study per prospect persona.** A B2B SaaS founder doesn't care about your restaurant client. Match the case study to the prospect.
- **Get written permission.** Before publishing any case study, get the client's written approval on the final version. Some companies have PR policies that require legal review.
- **No results? Show the process.** If you're too early to have measurable outcomes, write about the engagement experience — what you delivered, how the client responded, what changed qualitatively.
- **Ask for testimonials while you're still top of mind.** The best time to ask is right after a successful delivery or a positive comment. The worst time is 6 months later when they've forgotten the details.
- **Use their words, not yours.** When a client says "You guys saved our ass during Q4," that's more powerful than any marketing copy you could write. Don't clean it up.
