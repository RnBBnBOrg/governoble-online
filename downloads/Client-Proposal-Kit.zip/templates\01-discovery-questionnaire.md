# Discovery Questionnaire

The proposal you send is only as good as the discovery conversation that precedes it. Use these frameworks to run a thorough discovery — before you ever open a blank document.

---

## Template 1: General Discovery — Any Service Business

Use this for consulting, agencies, freelancers, or any service where you need to understand the client's situation before proposing a solution.

---

### Before the Call

Send this to the prospect 24 hours before your discovery call:

> Hi [Name],
>
> Looking forward to our call on [day/time]. To make the most of our time together, it would help if you could think through a few things beforehand — no need to write anything formal, just have these top of mind:
>
> 1. What's the main problem or opportunity you're trying to address?
> 2. What have you already tried?
> 3. What does success look like for you — how will you know this worked?
>
> Talk soon.
>
> [Your Name]

---

### Discovery Call Framework

Run through these in order. The first half is about their world; the second half is about fit. Budget 45-60 minutes.

**1. Situation (5 min)**

- Tell me about your business. What do you do and who do you serve?
- How big is your team? What does your org look like?
- How long have you been operating?

**2. Problem (10 min)**

- What prompted you to reach out now? What changed?
- How long has this been an issue?
- What's the impact — lost revenue, wasted time, missed opportunities?
- Who else on your team is affected by this?

**3. Prior Attempts (5 min)**

- What have you tried so far to solve this?
- What worked? What didn't?
- Have you worked with someone like me/us before? How did that go?

**4. Desired Outcome (10 min)**

- If we're wildly successful, what does that look like in 6 months?
- What specific metrics or outcomes would make this a win?
- What would make you feel like this was money well spent?

**5. Constraints (5 min)**

- What's your timeline? Is there a hard deadline?
- Who makes the final decision on this? Is anyone else involved in the approval?
- Do you have a budget range in mind? (See the pricing guide for how to handle this question.)

**6. Fit & Process (10 min)**

- How do you prefer to communicate — email, Slack, calls?
- How involved do you want to be in the day-to-day, or do you prefer a hands-off approach?
- Is there anything that would be a dealbreaker for you in working together?

**7. Next Steps (5 min)**

- Based on what we've discussed, I think I can help. Here's what I'd like to do next: [outline your proposal timeline]
- I'll have a proposal to you by [date]. Does that work?
- Is there anyone else who should review the proposal before we discuss it?

---

### Post-Call Notes Template

Fill this out immediately after the call. This becomes the foundation of your proposal.

| Field | Notes |
|-------|-------|
| **Prospect name** | |
| **Company** | |
| **Date of call** | |
| **Primary contact** | |
| **Decision maker(s)** | |
| **Core problem** | |
| **Impact of the problem** | |
| **What they've tried** | |
| **Desired outcome (in their words)** | |
| **Success metrics** | |
| **Timeline** | |
| **Budget range** | |
| **Communication preference** | |
| **Dealbreakers / concerns** | |
| **Competitors / alternatives they're considering** | |
| **Proposal due by** | |
| **Follow-up date** | |
| **My gut read (1-10 likelihood of closing)** | |

---

## Template 2: Project-Specific Discovery — Scoped Engagements

Use this when the prospect has a specific project in mind (a website, a marketing campaign, a system implementation) rather than ongoing services.

---

### Project Discovery Questions

**The What**

- Describe the project in your own words. What are you trying to build or accomplish?
- What does "done" look like? How will we know the project is finished?
- Are there examples of what you're looking for? (Competitors, references, inspiration)

**The Why**

- Why now? What happens if you delay this by 3-6 months?
- Who is the end user or audience for this project?
- What business outcome does this project drive? (Revenue, efficiency, compliance, brand)

**The How**

- Do you have existing assets we'd work with? (Brand guidelines, content, data, systems)
- Are there technical requirements or constraints? (Platform, integrations, security)
- Who on your team will be involved? What's their role?

**The When**

- Is there a launch date or deadline?
- What's driving that timeline — event, season, contractual obligation, or preference?
- Are there milestones or phases you'd want to see along the way?

**The How Much**

- Have you budgeted for this project? What range are you working within?
- How do you think about ROI for something like this?
- Is this funded from an existing budget or does it need separate approval?

---

## Template 3: Retainer/Ongoing Services Discovery

Use this when the prospect is looking for ongoing support rather than a one-time project.

---

### Retainer Discovery Questions

**Current State**

- Walk me through what a typical [week/month] looks like for the function I'd be supporting.
- Who handles this work right now? What's their capacity?
- What's falling through the cracks?

**Scope Definition**

- If you could hand off 5 things tomorrow, what would they be?
- Of those, which ones are urgent and which are important but not urgent?
- What do you absolutely need to keep in-house vs. what can I fully own?

**Working Relationship**

- How many hours per week/month do you think you need?
- Do you need availability during specific hours, or is async okay?
- How do you want to track what I'm working on? (Reports, tool access, weekly calls)

**Success Criteria**

- At the end of Month 1, what would make you glad you hired me?
- At the end of Month 3?
- What would cause you to end the engagement?

---

## Tips

- **Discovery is not a pitch.** You're there to listen. If you're talking more than 30% of the time, you're doing it wrong.
- **Write down their exact words.** When the proposal echoes their language back to them, it feels custom — because it is.
- **Ask "What else?" at least twice.** The first answer is the surface answer. The real problem usually comes out on the second or third follow-up.
- **Don't skip the budget question.** Asking about budget isn't pushy — it's respectful of both your time. You need to know if there's a fit before you spend hours writing a proposal.
- **Get the decision-making process clear.** "Who else needs to approve this?" prevents the proposal from disappearing into a forwarded email chain you never hear from again.
- **Send a summary within 24 hours.** A quick "here's what I heard" email after the discovery call confirms alignment and shows professionalism. It also creates a paper trail if scope creeps later.
