# Proposal Templates

Professional proposals that sell the outcome, not the hours. Each template follows the same structure: start with their problem, show you understand it, present the solution, make the investment clear, and make it easy to say yes.

---

## Template 1: Service Proposal — Consulting / Professional Services

---

### [Project/Engagement Name]

**Prepared for:** [Client Name], [Company]
**Prepared by:** [Your Name], [Your Company]
**Date:** [Date]
**Valid through:** [Date — typically 30 days]

---

#### Executive Summary

[2-3 sentences that restate the problem in their words and preview the solution. This is the only section some decision-makers will read — make it count.]

> Example: "[Company] is losing an estimated $X per month due to [problem you uncovered in discovery]. This proposal outlines a [timeframe] engagement to [solve that problem], with a target outcome of [specific measurable result]."

---

#### The Situation

[Summarize what you learned in discovery. Demonstrate that you listened and understand their world. Use their language, not yours.]

- [Key challenge 1 — stated in their words]
- [Key challenge 2]
- [Impact of inaction — what happens if they do nothing?]

---

#### The Solution

[Describe what you'll do — in terms of outcomes, not activities. Clients don't buy your time; they buy the result.]

**Phase 1: [Name] — [Timeline]**

- [Deliverable or milestone]
- [Deliverable or milestone]
- Outcome: [What this phase achieves for them]

**Phase 2: [Name] — [Timeline]**

- [Deliverable or milestone]
- [Deliverable or milestone]
- Outcome: [What this phase achieves for them]

**Phase 3: [Name] — [Timeline]**

- [Deliverable or milestone]
- [Deliverable or milestone]
- Outcome: [What this phase achieves for them]

---

#### What's Included

| Included | Not Included |
|----------|-------------|
| [Specific deliverable] | [Out of scope item] |
| [Specific deliverable] | [Out of scope item] |
| [Specific deliverable] | [Out of scope item] |
| [Meetings / communication cadence] | [Anything they might assume is included] |

---

#### Timeline

| Milestone | Target Date |
|-----------|------------|
| Kickoff | [Date] |
| [Phase 1 complete] | [Date] |
| [Phase 2 complete] | [Date] |
| [Final delivery / launch] | [Date] |

---

#### Investment

**Option A: [Recommended package name]**
$[Amount] — [one-time / monthly / per phase]

Includes: [Brief summary of everything in this option]

**Option B: [Premium / expanded package name]**
$[Amount] — [one-time / monthly / per phase]

Includes: Everything in Option A, plus [additional scope]

**Payment terms:** [50% upfront, 50% on completion / Monthly invoicing / Net 30]

---

#### Why [Your Company]

[3-4 sentences — not a bio, but a reason to trust you with this specific problem. Reference relevant experience, results, or perspective.]

---

#### Next Steps

1. Review this proposal and send any questions to [email]
2. To proceed, sign below and return by [date]
3. Upon receipt, I'll send an invoice for [deposit amount] and schedule our kickoff for [proposed date]

---

**Acceptance**

I approve this proposal and authorize [Your Company] to begin work as described above.

Signature: _________________________ Date: _____________

Print name: _________________________ Title: _____________

---

## Template 2: Project Proposal — Fixed Scope / Fixed Price

---

### [Project Name]

**For:** [Client Name], [Company]
**From:** [Your Name], [Your Company]
**Date:** [Date]
**Valid for:** 30 days

---

#### What You Need

[1-2 paragraphs restating the project in their words. What they told you in discovery, reflected back.]

---

#### What We'll Build / Deliver

[Describe the tangible output — the thing they'll have at the end.]

**Deliverables:**

1. **[Deliverable 1]** — [One-sentence description of what it is and what it does for them]
2. **[Deliverable 2]** — [Description]
3. **[Deliverable 3]** — [Description]
4. **[Deliverable 4]** — [Description]

**Included in this project:**
- [Rounds of revision]
- [Meetings or check-ins]
- [Training or documentation]
- [Post-launch support period, if any]

**Not included:**
- [Explicitly out of scope item]
- [Explicitly out of scope item]
- [Anything that could cause scope creep]

---

#### How It Works

| Step | What Happens | Timeline |
|------|-------------|----------|
| 1. Kickoff | [Collect assets, align on details, confirm schedule] | Week 1 |
| 2. [Phase name] | [What you'll do] | Weeks 2-3 |
| 3. [Phase name] | [What you'll do] | Weeks 4-5 |
| 4. Review & Revisions | [Client reviews, you refine] | Week 6 |
| 5. Delivery | [Final handoff, training if applicable] | Week 7 |

---

#### Investment

**Project fee:** $[Amount]

**Payment schedule:**
- $[Amount] (50%) due upon signing
- $[Amount] (50%) due upon delivery

**What's not covered:** Additional scope beyond what's listed above will be quoted separately before any work begins. No surprises.

---

#### Let's Go

Reply to this email with "approved" or sign below and I'll send the kickoff details within 24 hours.

Signature: _________________________ Date: _____________

---

## Template 3: Retainer Proposal — Ongoing Services

---

### Monthly [Service Type] Retainer

**For:** [Client Name], [Company]
**From:** [Your Name], [Your Company]
**Date:** [Date]

---

#### What We Discussed

[Summary of their needs from the retainer discovery conversation. What they need handled, what's falling through the cracks, what capacity they're missing.]

---

#### How the Retainer Works

**Monthly scope:** [X] hours per month dedicated to [service area]

**What's covered:**
- [Core service 1 — e.g., "Content strategy and production (blog posts, social, email)"]
- [Core service 2 — e.g., "Campaign management and optimization"]
- [Core service 3 — e.g., "Monthly reporting and strategy calls"]

**How we work together:**
- [Communication method] — [response time expectations]
- [Weekly/biweekly/monthly] check-in calls ([day/time])
- [Tool for tracking work — Notion, Asana, Slack channel, etc.]
- Monthly report delivered by [day of month]

**What's not covered:**
- [Out of scope — e.g., "Paid ad spend (billed separately at cost)"]
- [Out of scope — e.g., "One-off projects exceeding X hours (quoted separately)"]

---

#### Investment

| Tier | Hours/Month | Monthly Rate | Best For |
|------|-------------|-------------|----------|
| **Starter** | [X] hrs | $[Amount]/mo | [Who this fits — "Solopreneurs who need consistent support"] |
| **Growth** | [X] hrs | $[Amount]/mo | [Who this fits — "Growing teams with multiple initiatives"] |
| **Scale** | [X] hrs | $[Amount]/mo | [Who this fits — "Businesses that need a fractional department"] |

**Recommended for you:** [Tier] — based on what you described, [X] hours gives us enough room to [accomplish what they need].

**Terms:**
- Month-to-month — no long-term contract required
- [30 days] written notice to cancel
- Unused hours [do not / do] roll over
- Overage hours billed at $[rate]/hr with prior approval

---

#### Getting Started

1. Choose your tier and confirm via email or signature below
2. I'll send the first invoice and schedule our kickoff call
3. We start [proposed date]

Signature: _________________________ Date: _____________

---

## Tips

- **Lead with their problem, not your credentials.** The client should see themselves in the first paragraph. If the proposal opens with your company bio, you've lost them.
- **Always include "What's not included."** This prevents scope creep and sets expectations. If you don't define the boundary, the client will.
- **Give two options, recommend one.** Two options give the client agency. Three creates decision paralysis. One feels like a take-it-or-leave-it ultimatum.
- **Price the outcome, not the hours.** "A hiring process that fills the role in 30 days" is worth more than "40 hours of consulting." Frame accordingly.
- **Set an expiration date.** A proposal without a deadline sits in someone's inbox forever. 30 days is standard.
- **Make it easy to say yes.** "Reply with 'approved'" has less friction than "print, sign, scan, email back." Remove every barrier you can.
- **Follow up.** See the follow-up templates (05) — a proposal without follow-up is a wish, not a sales process.
