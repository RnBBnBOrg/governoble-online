# AI Prompts: Client Communications

Prompts for the messages you send throughout the client lifecycle — from winning the deal to wrapping the engagement.

---

## Prompt 1: Write a "We Won the Deal" Welcome Sequence

> A client just signed my proposal. Here are the details:
>
> - **Client:** [Name, Company]
> - **Project/Service:** [What you'll be doing]
> - **Start date:** [Date]
> - **What they need to provide before we start:** [Assets, access, info]
> - **First milestone:** [What it is and when]
>
> Write three emails:
> 1. **Welcome email** (send immediately) — Confirm the engagement, express genuine enthusiasm, outline what happens next and what you need from them before kickoff
> 2. **Kickoff prep email** (send 3-5 days before start) — Checklist of what to have ready, calendar invite details, what to expect in the first week
> 3. **Day 1 email** (send on start day) — Set the tone, confirm communication cadence, let them know where to reach you
>
> Tone: professional but personal. They should feel like they made the right decision.

---

## Prompt 2: Write a Project Update

> I need to send a progress update to my client. Here's where we are:
>
> - **Project:** [Name]
> - **Current phase:** [What phase/milestone we're in]
> - **What's been completed since last update:** [List]
> - **What's in progress:** [List]
> - **What's coming next:** [List]
> - **Any blockers or risks:** [What might slow things down]
> - **Anything I need from them:** [Feedback, approvals, assets]
>
> Write a concise project update email that:
> - Leads with progress, not problems
> - Clearly states what I need from them (with deadlines)
> - Is under 200 words — busy clients don't read novels
> - Ends with next steps and the next update date

---

## Prompt 3: Deliver Bad News to a Client

> I need to tell a client something they won't want to hear. Here's the situation:
>
> - **Client:** [Name]
> - **The bad news:** [e.g., "We're going to miss the deadline by 2 weeks" / "The budget needs to increase" / "I found a problem that changes the scope" / "I need to bring in additional help" / "The approach we agreed on isn't working"]
> - **Why it happened:** [Be honest]
> - **What I'm doing about it:** [Your plan]
> - **What I need from them:** [Decision, approval, patience]
>
> Write a message that:
> 1. States the issue directly — no burying the lead
> 2. Takes appropriate ownership (don't over-apologize, don't deflect)
> 3. Presents a solution or options, not just the problem
> 4. Preserves trust — they should feel informed, not blindsided
>
> Should I email this or call first? Advise me on the medium based on the severity.

---

## Prompt 4: Ask for a Rate Increase

> I need to raise my rates with an existing client. Here's the context:
>
> - **Current rate:** $[amount] per [hour/month/project]
> - **New rate:** $[amount]
> - **How long they've been at the current rate:** [X months/years]
> - **Why I'm raising rates:** [Increased demand, added capabilities, market rate, cost of doing business]
> - **How important this client is to me (1-10):** [X]
> - **How price-sensitive I think they are:** [Very / Moderate / They probably expect it]
>
> Write the email or talking points for this conversation. Help me:
> 1. Frame the increase as fair and expected, not apologetic
> 2. Give enough notice (typically 30-60 days)
> 3. Acknowledge the relationship and the value of their loyalty
> 4. Be prepared for pushback — what should I say if they ask me to hold the old rate?

---

## Prompt 5: Write a Project Wrap-Up / Offboarding Email

> I just completed a project with a client. Here's the context:
>
> - **Client:** [Name, Company]
> - **Project:** [What you did]
> - **Key results:** [What was delivered, any measurable outcomes]
> - **Anything still outstanding:** [Warranty period, support window, final invoice]
> - **Do I want to work with them again?** [Yes — actively / Yes — if they come back / Not really]
>
> Write a wrap-up email that:
> 1. Summarizes what was accomplished
> 2. Confirms any remaining obligations (support period, final deliverables)
> 3. Opens the door for future work without being pushy
> 4. Asks for a testimonial or referral (naturally, not awkwardly)
> 5. Ends the engagement on a high note

---

## Prompt 6: Handle Scope Creep

> My client is asking for work that's outside the original scope. Here's what's happening:
>
> - **Original scope:** [What was agreed to]
> - **What they're asking for now:** [The additional work]
> - **Is it reasonable?** [Minor addition that's easy to absorb / Significant work that should be billed / A complete redirection of the project]
> - **How I want to handle it:** [Absorb it this time / Quote it as additional / Push back]
>
> Write a message that:
> 1. Acknowledges their request positively (don't make them feel bad for asking)
> 2. Clearly explains that it's outside the agreed scope
> 3. Presents options (absorb it with a trade-off, quote additional cost, defer to a Phase 2)
> 4. Protects the relationship while protecting my time and margins

---

## Prompt 7: Request a Referral

> I want to ask a happy client for referrals. Here's the context:
>
> - **Client:** [Name, Company]
> - **What I did for them:** [Service/project]
> - **How happy they seem:** [Very satisfied / Satisfied / Hard to read]
> - **When we last worked together:** [Currently active / Finished recently / Finished months ago]
> - **Who I'd ideally want a referral to:** [Industry, role, company type]
>
> Write a referral request that:
> - Doesn't feel transactional or desperate
> - Makes it easy for them (be specific about who you're looking to meet)
> - Gives them language to use when introducing you
> - Optionally offers a referral incentive if appropriate
>
> Also: should I ask via email, phone, or in person? Advise based on the context.

---

## Prompt 8: Win Back a Lost Client

> A client I used to work with hasn't engaged me in [X months/years]. I want to reconnect. Here's the background:
>
> - **Client:** [Name, Company]
> - **What I did for them:** [Past services]
> - **How the engagement ended:** [Naturally / Budget cuts / They went in-house / Chose a competitor / Unclear]
> - **What's changed since then:** [New services I offer, results from similar clients, industry changes]
> - **What I think they might need now:** [Your best guess]
>
> Write a re-engagement message that:
> 1. Is warm and genuine, not "I noticed we haven't talked in a while" (they know)
> 2. Leads with something relevant to THEM, not an update about MY business
> 3. Creates a reason to reconnect that isn't just "I want your money"
> 4. Is short enough to actually get read (under 100 words)
