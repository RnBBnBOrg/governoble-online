# Client Proposal Kit

Everything you need to win clients — from discovery call to signed contract.

## What's Inside

- **6 templates** covering discovery, proposals, scopes of work, pricing, follow-up, and case studies
- **23 AI prompts** to write proposals, prep for calls, handle objections, and manage clients
- **Quick-start guide** with a full sales process walkthrough

## Where to Start

Open `guides/quick-start.md` for a step-by-step walkthrough.

## Folder Structure

```
templates/          — Fill-in-the-blank documents for each sales stage
  01-discovery-questionnaire.md
  02-proposal.md
  03-scope-of-work.md
  04-pricing-guide.md
  05-follow-up-sequences.md
  06-case-study.md

prompts/            — Copy-paste AI prompts for any AI tool
  proposal-writer.md              (8 prompts)
  discovery-coach.md              (7 prompts)
  client-communications.md        (8 prompts)

guides/             — How to use this toolkit
  quick-start.md
```
