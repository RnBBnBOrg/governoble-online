# Pricing Guide & Rate Sheet Templates

How you present pricing shapes how clients perceive your value. These templates and frameworks help you price confidently and present it professionally.

---

## Template 1: Service Rate Sheet

A polished reference you can send to qualified prospects or include in proposals.

---

### [Your Company] — Services & Rates

**Effective:** [Date]

---

#### Consulting / Advisory

| Service | Rate | Details |
|---------|------|---------|
| Strategy session (one-time) | $[Amount] | [Duration], includes summary + action plan |
| Ongoing advisory | $[Amount]/month | [X] calls/month, async support, [deliverables] |
| Half-day intensive | $[Amount] | [4 hours], focused on [single topic/deliverable] |
| Full-day intensive | $[Amount] | [8 hours], deep dive on [scope] |

#### Project Work

| Service | Starting At | Typical Range | Includes |
|---------|------------|--------------|----------|
| [Service 1 — e.g., Brand Strategy] | $[Amount] | $[Low]-$[High] | [Key deliverables] |
| [Service 2 — e.g., Website Design] | $[Amount] | $[Low]-$[High] | [Key deliverables] |
| [Service 3 — e.g., Process Audit] | $[Amount] | $[Low]-$[High] | [Key deliverables] |

#### Retainer Packages

| Tier | Hours/Month | Rate | Best For |
|------|-------------|------|----------|
| **[Tier 1]** | [X] hrs | $[Amount]/mo | [Ideal client profile] |
| **[Tier 2]** | [X] hrs | $[Amount]/mo | [Ideal client profile] |
| **[Tier 3]** | [X] hrs | $[Amount]/mo | [Ideal client profile] |

*Custom scopes available. All retainers are month-to-month with 30-day cancellation notice.*

---

**Notes:**
- All rates are USD. Travel expenses billed separately at cost.
- Rush work (less than [X] days turnaround) subject to [25-50]% surcharge.
- Rates valid through [date]. Annual adjustments communicated 60 days in advance.

---

## Template 2: Tiered Pricing Presentation

Use this inside proposals to present good/better/best options.

---

### Investment Options

| | **Essentials** | **Professional** | **Premium** |
|---|:---:|:---:|:---:|
| [Core deliverable 1] | Included | Included | Included |
| [Core deliverable 2] | Included | Included | Included |
| [Enhanced deliverable 1] | — | Included | Included |
| [Enhanced deliverable 2] | — | Included | Included |
| [Premium deliverable 1] | — | — | Included |
| [Premium deliverable 2] | — | — | Included |
| [Support level] | Email only | Email + calls | Dedicated support |
| [Revisions] | [1] round | [2] rounds | [3] rounds |
| **Investment** | **$[Amount]** | **$[Amount]** | **$[Amount]** |

**Recommended:** Professional — gives you [key benefit] without [what premium adds that they may not need yet].

---

## Pricing Frameworks

These aren't templates — they're thinking tools. Use them to set your rates before you build the proposal.

---

### Framework 1: Cost-Plus Pricing

The simplest approach. Calculate your costs, add your margin.

| Component | Amount |
|-----------|--------|
| Your time: [X] hours × $[your hourly rate] | $[Amount] |
| Subcontractors / tools / materials | $[Amount] |
| Overhead allocation | $[Amount] |
| **Total cost** | **$[Amount]** |
| Desired margin ([X]%) | $[Amount] |
| **Quoted price** | **$[Amount]** |

**When to use:** When you're starting out and need a floor. Don't stay here — this underprices you because it ties revenue to time.

---

### Framework 2: Value-Based Pricing

Price based on the value the client receives, not the hours you put in.

| Question | Answer |
|----------|--------|
| What's the problem costing them per month/year? | $[Amount] |
| What's the upside if the problem is solved? | $[Amount] |
| What percentage of that value is fair for your contribution? | [10-20]% |
| **Quoted price** | **$[Amount]** |

**Example:** A client losing $10K/month to inefficiency hires you to fix it. The fix takes you 20 hours. At $150/hr, cost-plus pricing says $3,000. Value-based pricing says $10K-$24K (1-2 months of the problem's cost), because that's what the solution is worth to them.

**When to use:** When you can quantify the impact. This is where the real money is.

---

### Framework 3: Market-Rate Anchoring

Research what competitors charge and position yourself relative to the market.

| Data Point | Rate |
|-----------|------|
| Low end of market | $[Amount] |
| Market average | $[Amount] |
| High end of market | $[Amount] |
| **Your position** | $[Amount] — [why: "Above average due to X specialization"] |

**Where to find rates:**
- Glassdoor (for employee equivalents)
- Clutch.co (for agency rates)
- Industry-specific salary surveys
- Ask peers directly — most people will share ranges

---

### The Budget Conversation

How to ask about budget without being awkward:

**If they volunteer a number:**
"That gives us a good starting point. Let me show you what's possible within that range."

**If they say "What do you charge?":**
"It depends on scope, but most clients working on something like this invest between $[low end] and $[high end]. Once I understand your needs better, I can give you a precise number."

**If they say "I don't have a budget":**
"That's fine — I'll put together options at different levels so you can see what's possible. That usually helps frame the conversation."

**If they say the budget is lower than your floor:**
"I appreciate you sharing that. At that level, here's what I could realistically deliver: [reduced scope]. If you need the full scope we discussed, the investment would be closer to $[your number]. Would either of those work for you?"

---

## Tips

- **Never send a rate sheet to an unqualified prospect.** A rate sheet without context is just a reason to shop on price. Use discovery first, then present pricing inside a proposal where the value is already established.
- **Three tiers is the sweet spot.** One option is a take-it-or-leave-it. Two options is a this-or-that. Three options anchors the middle as the "smart choice."
- **Name your tiers, don't number them.** "Professional" feels like a decision. "Option 2" feels like a spreadsheet.
- **Anchor high.** Put the premium option first. Everything after it feels reasonable by comparison.
- **The one who names the number first usually loses.** Try to understand their budget before you quote. If you must go first, give a range, not a point.
- **Raise your prices.** If no one ever pushes back on your pricing, you're too cheap. You should lose about 20-30% of proposals on price — that means you're priced right for the other 70-80%.
