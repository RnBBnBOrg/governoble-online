# Scope of Work Templates

The proposal gets the "yes." The scope of work protects you both after the handshake. These are more detailed and more binding than the proposal — they define exactly what's being delivered, by whom, and by when.

---

## Template 1: General Scope of Work

---

### Scope of Work

**Project:** [Project Name]
**Client:** [Client Name], [Company]
**Provider:** [Your Name], [Your Company]
**Effective date:** [Date]
**Completion date:** [Date]

---

#### 1. Purpose

This Scope of Work defines the services, deliverables, timeline, and terms for [brief description of the engagement]. It is entered into based on the proposal dated [date] and the discovery conversations between [Client] and [Provider].

---

#### 2. Services

[Provider] will perform the following services:

**2.1 [Phase/Service Area 1: Name]**
- [Specific task or deliverable]
- [Specific task or deliverable]
- [Specific task or deliverable]

**2.2 [Phase/Service Area 2: Name]**
- [Specific task or deliverable]
- [Specific task or deliverable]
- [Specific task or deliverable]

**2.3 [Phase/Service Area 3: Name]**
- [Specific task or deliverable]
- [Specific task or deliverable]

---

#### 3. Deliverables

| # | Deliverable | Format | Due Date |
|---|------------|--------|----------|
| 1 | [Deliverable name] | [PDF / Figma / Source code / Document] | [Date] |
| 2 | [Deliverable name] | [Format] | [Date] |
| 3 | [Deliverable name] | [Format] | [Date] |
| 4 | [Deliverable name] | [Format] | [Date] |
| 5 | [Final deliverable] | [Format] | [Date] |

---

#### 4. Timeline

| Phase | Start | End | Milestone |
|-------|-------|-----|-----------|
| Kickoff & planning | [Date] | [Date] | Project plan approved |
| [Phase 2] | [Date] | [Date] | [Milestone] |
| [Phase 3] | [Date] | [Date] | [Milestone] |
| Review & revisions | [Date] | [Date] | Final approval |
| Delivery / handoff | [Date] | [Date] | Project complete |

---

#### 5. Client Responsibilities

The client agrees to provide:

- [Assets, content, or materials needed — with deadline]
- [Access to systems, accounts, or tools]
- [Designated point of contact for approvals]
- [Feedback/approval turnaround time — e.g., "within 3 business days"]
- [Availability for scheduled check-ins]

**Delays caused by late client deliverables will extend the project timeline accordingly.**

---

#### 6. Exclusions

The following are explicitly **not included** in this scope:

- [Out of scope item]
- [Out of scope item]
- [Out of scope item]
- [Any ongoing maintenance, unless specified]

Additional work outside this scope will be documented in a separate SOW or change order and quoted before work begins.

---

#### 7. Compensation

| Item | Amount |
|------|--------|
| **Total project fee** | $[Amount] |
| **Deposit (due upon signing)** | $[Amount] ([X]%) |
| **Milestone payment** | $[Amount] due upon [milestone] |
| **Final payment** | $[Amount] due upon delivery |

**Payment method:** [Invoice via [platform] / ACH / Check]
**Payment terms:** Net [15/30] from invoice date
**Late payment:** Invoices unpaid after [X] days will incur a [X]% monthly late fee. Work may be paused on accounts more than [X] days overdue.

---

#### 8. Revisions & Change Orders

- [X] rounds of revisions are included in the project fee
- Additional revisions beyond the included rounds will be billed at $[rate]/hr
- Scope changes (new features, deliverables, or requirements not in this SOW) require a written change order approved by both parties before work begins

---

#### 9. Ownership & Intellectual Property

- Upon receipt of final payment, all deliverables become the property of [Client]
- [Provider] retains the right to display the work in portfolios and case studies unless otherwise agreed in writing
- [Provider] retains ownership of pre-existing tools, frameworks, and methodologies used in the engagement

---

#### 10. Termination

Either party may terminate this agreement with [14/30] days written notice. In the event of termination:

- Client pays for all work completed through the termination date
- Provider delivers all completed work and work-in-progress
- Deposit is non-refundable after project kickoff

---

#### 11. Signatures

**Client:**

Signature: _________________________ Date: _____________

Print name: _________________________ Title: _____________

**Provider:**

Signature: _________________________ Date: _____________

Print name: _________________________ Title: _____________

---

## Template 2: Retainer Scope of Work

---

### Monthly Retainer — Scope of Work

**Client:** [Client Name], [Company]
**Provider:** [Your Name], [Your Company]
**Start date:** [Date]
**Term:** Month-to-month, [30 days] written notice to cancel

---

#### 1. Services

[Provider] will provide the following ongoing services:

- [Service 1 — e.g., "Content creation: 4 blog posts and 12 social media posts per month"]
- [Service 2 — e.g., "Email marketing: 2 campaigns per month, including copywriting and scheduling"]
- [Service 3 — e.g., "Monthly strategy call and performance report"]

#### 2. Monthly Allocation

- **Hours included:** [X] hours/month
- **Rollover policy:** Unused hours [do / do not] roll to the following month
- **Overage rate:** $[amount]/hr, billed only with prior client approval
- **Tracking:** Hours tracked in [tool] with access shared with client

#### 3. Communication & Reporting

- **Primary channel:** [Email / Slack / tool]
- **Response time:** Within [X] business hours
- **Check-in calls:** [Weekly / biweekly / monthly] on [day] at [time]
- **Monthly report:** Delivered by the [Xth] of each month

#### 4. Client Responsibilities

- Provide [content, assets, approvals] within [X] business days of request
- Designate a single point of contact for approvals
- Attend scheduled check-in calls or provide [24 hours] notice to reschedule

#### 5. Compensation

- **Monthly retainer:** $[Amount]/month
- **Invoicing:** Sent on the [1st / 15th] of each month
- **Payment terms:** Due upon receipt / Net [15/30]
- **Late payment:** [Same terms as project SOW]

#### 6. Term & Termination

- This retainer begins on [date] and continues month-to-month
- Either party may cancel with [30 days] written notice
- Final invoice covers services through the end of the notice period

---

#### Signatures

**Client:**

Signature: _________________________ Date: _____________

**Provider:**

Signature: _________________________ Date: _____________

---

## Tips

- **The SOW is not the proposal.** The proposal sells. The SOW protects. Don't combine them — a client who's already said "yes" doesn't need to be sold again, and a prospect in decision mode doesn't need legal terms.
- **Be specific about deliverables.** "Website redesign" is a scope nightmare. "5-page responsive website with homepage, about, services, blog, and contact page" is a scope of work.
- **Always include client responsibilities.** Most project delays are caused by the client, not the provider. If they know what's expected of them — and that delays on their end extend the timeline — everyone's protected.
- **Define "done."** What constitutes final delivery? What does the client need to approve? How many revision rounds are included? Spell it out.
- **Get this reviewed by a professional.** These templates give you the structure, but your specific industry and jurisdiction may require additional terms. A contract attorney or business advisor can review for $200-500 and save you thousands in disputes.
