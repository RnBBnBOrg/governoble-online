# AI Prompts: Proposal Writer

Prompts to draft, refine, and strengthen client proposals using any AI tool.

---

## Prompt 1: Generate a Proposal from Discovery Notes

> I just finished a discovery call with a potential client. Here are my notes:
>
> - **Client:** [Name, Company, Industry]
> - **Their problem:** [What they told you]
> - **Impact of the problem:** [Cost, time, frustration — what it's doing to them]
> - **What they've tried:** [Prior attempts]
> - **Desired outcome:** [What success looks like in their words]
> - **Timeline:** [When they need it done]
> - **Budget range:** [If known]
> - **Decision maker(s):** [Who approves]
> - **My proposed solution:** [What you plan to do]
>
> Write a professional proposal that:
> - Opens with their problem in their own words (not my company bio)
> - Breaks the solution into clear phases with deliverables and timelines
> - Includes a "What's Included / Not Included" section
> - Presents two pricing options (recommend one)
> - Ends with clear next steps and an acceptance section
>
> Tone: professional but conversational — like a confident peer, not a corporate brochure.

---

## Prompt 2: Turn a Proposal into a Scope of Work

> Here's a proposal that's been approved by the client: [paste proposal]
>
> Convert it into a formal Scope of Work that includes:
> 1. Detailed deliverables list with formats and due dates
> 2. Timeline with milestones
> 3. Client responsibilities (what they need to provide and by when)
> 4. Exclusions (what's explicitly not included)
> 5. Payment schedule
> 6. Revision policy (how many rounds, what counts as a revision vs. scope change)
> 7. Termination clause
> 8. Signature blocks
>
> Keep the language clear and specific — this needs to protect both sides if there's ever a disagreement about what was agreed to.

---

## Prompt 3: Write a Pricing Justification

> I need to present a price of $[amount] for [service/project]. The client's budget is [lower than my price / unknown / they seem hesitant].
>
> Here's what's included: [list deliverables and scope]
>
> Here's the value to the client: [what it solves, saves, or produces for them]
>
> Help me:
> 1. Frame the price in terms of ROI, not cost
> 2. Compare it to the cost of NOT doing this (cost of inaction)
> 3. Compare it to alternatives they might consider (hiring in-house, cheaper providers, doing it themselves)
> 4. Write 2-3 sentences I can use in the proposal or on a call to present the investment confidently
>
> Don't be salesy — be direct and honest.

---

## Prompt 4: Create Tiered Pricing Options

> I need to present three pricing tiers for a [type of service] proposal. Here's the full scope I'd ideally deliver:
>
> [Describe the complete service/project]
>
> Help me break this into three tiers:
> - **Essentials** — the minimum viable version that still solves their core problem
> - **Professional** — the recommended option with the best value-to-price ratio
> - **Premium** — the full-service option with everything included
>
> For each tier:
> 1. Name it (not "Tier 1" — give it a real name)
> 2. List what's included and what's not
> 3. Suggest a price based on value-based pricing principles
> 4. Write one sentence explaining who this tier is best for
>
> Then tell me which tier to recommend and how to present it so the client naturally gravitates toward it.

---

## Prompt 5: Rewrite a Proposal That Didn't Close

> I sent this proposal and the prospect didn't move forward: [paste proposal]
>
> They said: "[their objection or reason for passing — e.g., 'too expensive,' 'not the right time,' 'went with someone else,' or no response at all]"
>
> Analyze the proposal and tell me:
> 1. Where it might have lost them (weak opening, unclear value, poor pricing presentation, etc.)
> 2. What's missing that could have strengthened it
> 3. Whether the tone matches the client's likely expectations
> 4. Rewrite the weakest section to show what it could look like
>
> Be honest — I want to get better, not feel good.

---

## Prompt 6: Draft a Follow-Up Sequence for a Sent Proposal

> I sent a proposal to [Client Name] at [Company] on [date] for [brief description of the project]. The total investment is $[amount].
>
> Here's what I know about them:
> - [Decision-making timeline / urgency level]
> - [Who else is involved in the decision]
> - [Any competing priorities or alternatives they mentioned]
>
> Write a 4-email follow-up sequence:
> 1. Day 1 — confirmation that the proposal was sent
> 2. Day 3 — check-in that adds value (not "just following up")
> 3. Day 7 — direct ask for feedback or a call
> 4. Day 14 — final follow-up with a graceful exit
>
> Tone: confident and professional, not needy. Each email should be under 100 words.

---

## Prompt 7: Build a Case Study from Project Notes

> I completed a project and want to turn it into a case study. Here's what happened:
>
> - **Client:** [Name/Industry/Size — or anonymous if preferred]
> - **Their situation before:** [What was going on when they hired you]
> - **What I did:** [Your approach, phases, key decisions]
> - **Results:** [Numbers if possible — revenue, time saved, efficiency gains, etc.]
> - **Client feedback:** [Any quotes or reactions from the client]
>
> Write a case study in this structure:
> 1. **Headline** — lead with the result, not the client name
> 2. **The Challenge** — 2-3 paragraphs about their problem (make it relatable to similar prospects)
> 3. **The Solution** — what I did and why I chose this approach
> 4. **The Results** — hard numbers first, then qualitative outcomes
> 5. **Client Quote** — if I provided one, format it as a testimonial
>
> Write it so a prospect in a similar situation reads it and thinks "that's exactly what I need."

---

## Prompt 8: Prepare for a Pricing Objection Call

> A prospect came back and said my proposal is too expensive. Here's the situation:
>
> - **My price:** $[amount]
> - **What they said:** "[their exact words or reaction]"
> - **What I think their real objection is:** [price vs. value vs. budget vs. comparison to competitor]
> - **What I'm willing to flex on:** [scope, timeline, payment terms, nothing]
> - **What I'm NOT willing to flex on:** [hourly rate, quality, specific deliverables]
>
> Help me prepare for a call where I address this:
> 1. How to open the conversation (not defensive, not apologetic)
> 2. Questions to ask that uncover the real objection
> 3. If it's truly about price: how to adjust scope without devaluing my work
> 4. If it's about value: how to reframe the investment
> 5. A graceful way to walk away if the fit isn't there
>
> Give me actual scripts I can use on the call, not just strategy.
