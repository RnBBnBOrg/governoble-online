# AI Prompts: Discovery & Sales Conversations

Prompts to prepare for discovery calls, handle objections, and close with confidence.

---

## Prompt 1: Prepare for a Discovery Call

> I have a discovery call coming up with a potential client. Here's what I know so far:
>
> - **Prospect:** [Name, Company, Title]
> - **How they found me:** [Referral, website, cold outreach, etc.]
> - **What they said in their initial message:** [Paste their email or message]
> - **My service/product:** [What you do]
> - **What I think they need:** [Your best guess based on initial info]
>
> Help me prepare:
> 1. What research should I do before the call? (Company, industry, recent news)
> 2. Write 8-10 discovery questions tailored to their likely situation — prioritized from most important to nice-to-have
> 3. What red flags should I watch for that signal this isn't a good fit?
> 4. How should I handle the budget question for this specific situation?
> 5. Suggest a natural way to end the call and set up next steps

---

## Prompt 2: Handle a Specific Objection

> A prospect just raised this objection: "[Their exact words — e.g., 'We need to think about it,' 'We're talking to other providers,' 'Can you do it for less?', 'Our CEO needs to approve this,' 'We tried something like this before and it didn't work']"
>
> Context:
> - **What I'm selling:** [Your service/product]
> - **Price:** $[amount]
> - **Where we are in the process:** [Discovery / Proposal sent / Negotiation]
> - **How badly I want this deal (1-10):** [X]
>
> Help me:
> 1. Identify what the real objection is (it's often not what they said)
> 2. Give me 2-3 response options ranging from soft to direct
> 3. Tell me what question to ask next to keep the conversation moving
> 4. If this objection is a dealbreaker, tell me — and give me a graceful way to move on

---

## Prompt 3: Write a Post-Discovery Summary Email

> I just had a discovery call. Here are my raw notes:
>
> [Paste your notes — can be messy, bullet points, stream of consciousness]
>
> Turn this into a professional summary email that I can send to the prospect within 2 hours. Structure it as:
> 1. Thank them for their time
> 2. Summarize what I heard (their situation, challenges, goals — in their words)
> 3. Confirm next steps (what I'll do, what they'll do, when)
> 4. Keep it under 200 words
>
> Tone: professional, warm, and specific. Not generic or templated.

---

## Prompt 4: Qualify a Lead — Should I Pursue This?

> I received an inquiry from a potential client. Before I invest time in a discovery call, help me qualify whether this is worth pursuing.
>
> Here's what I know:
> - **Their message:** [Paste their email/form submission/DM]
> - **My ideal client profile:** [Describe your best-fit client — industry, size, budget range, problem type]
> - **My capacity right now:** [Busy / Available / Selectively taking on work]
> - **Red flags I've seen before:** [E.g., "Clients who want everything for nothing," "Prospects who can't articulate what they need"]
>
> Evaluate this lead:
> 1. On a scale of 1-10, how well does this match my ideal client?
> 2. What signals are promising?
> 3. What signals are concerning?
> 4. Should I take the call, ask qualifying questions first, or pass?
> 5. If I should ask qualifying questions before committing to a call, write 3-4 I can send via email

---

## Prompt 5: Role-Play a Difficult Sales Conversation

> I need to practice a sales conversation before I have it for real. Here's the situation:
>
> - **Prospect:** [Name, Company, what they do]
> - **What they need:** [The project or service]
> - **The awkward part:** [What makes this conversation tricky — e.g., "They're a friend and I need to name a price," "They want a discount because they're a big company," "They had a bad experience with my competitor and are skeptical," "I'm raising my rates and they're an existing client"]
>
> Play the prospect. Be realistic — push back where a real person would, raise objections, and don't make it easy for me. After 6-8 exchanges, break character and give me feedback on:
> - Where I was strong
> - Where I lost ground or got defensive
> - What I should say differently next time

---

## Prompt 6: Research a Prospect Before a Call

> I have a call with [Name] at [Company] on [date]. I need to do my homework.
>
> Here's what I know: [Whatever you already have — LinkedIn URL, website, how they found you]
>
> Help me build a research brief:
> 1. What should I look for on their website and LinkedIn?
> 2. What industry trends or challenges are likely top of mind for someone in their role?
> 3. What smart questions can I ask that show I've done my research without being creepy about it?
> 4. What common pain points does someone in [their role] at a [their company size] company typically face?
>
> Note: I know you can't browse the web. Give me a framework for what to look for and where.

---

## Prompt 7: Write a Warm Outreach Message

> I want to reach out to a potential client without being cold or salesy. Here's the situation:
>
> - **Who they are:** [Name, Company, Role]
> - **How I know of them:** [Referral from [name] / Met at [event] / Saw their post about [topic] / They visited my website]
> - **What I think I can help with:** [Your best guess at their need]
> - **Where I'm reaching out:** [Email / LinkedIn / DM]
>
> Write a short outreach message (under 100 words) that:
> - References the connection or context naturally
> - Identifies a specific problem I might help with (not a generic "I help businesses grow")
> - Asks a question that starts a conversation (not a pitch)
> - Doesn't include the word "synergy," "touch base," or "pick your brain"
