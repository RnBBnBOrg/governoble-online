# Financial Tracker

You're running a business, not a hobby. These templates help you track revenue, expenses, occupancy, and profitability so you can make decisions based on numbers, not gut feel.

---

## Template 1: Monthly Revenue & Occupancy Tracker

---

### [Year] — Monthly Summary

| Month | Available Nights | Booked Nights | Occupancy % | Gross Revenue | Avg Nightly Rate | Platform Fees | Cleaning Income | Net Revenue |
|-------|-----------------|--------------|-------------|---------------|-----------------|---------------|-----------------|-------------|
| Jan | | | | $ | $ | $ | $ | $ |
| Feb | | | | $ | $ | $ | $ | $ |
| Mar | | | | $ | $ | $ | $ | $ |
| Apr | | | | $ | $ | $ | $ | $ |
| May | | | | $ | $ | $ | $ | $ |
| Jun | | | | $ | $ | $ | $ | $ |
| Jul | | | | $ | $ | $ | $ | $ |
| Aug | | | | $ | $ | $ | $ | $ |
| Sep | | | | $ | $ | $ | $ | $ |
| Oct | | | | $ | $ | $ | $ | $ |
| Nov | | | | $ | $ | $ | $ | $ |
| Dec | | | | $ | $ | $ | $ | $ |
| **Total** | | | **Avg:** | **$** | **$** | **$** | **$** | **$** |

**Notes:**
- Available Nights = Calendar days minus owner blocks and maintenance holds
- Occupancy % = Booked Nights / Available Nights
- Platform Fees = Airbnb/VRBO host fees deducted from payouts
- Cleaning Income = Cleaning fees collected from guests (offset against cleaning expenses below)

---

## Template 2: Monthly Expense Tracker

---

### [Month / Year]

| Category | Description | Date | Amount | Receipt? | Tax Deductible? |
|----------|------------|------|--------|----------|----------------|
| **Mortgage/Rent** | | | $ | | |
| **HOA/Condo fees** | | | $ | | |
| **Property tax** | | | $ | | |
| **Insurance** | | | $ | | |
| **Utilities** | | | | | |
| Electric | | | $ | | Yes |
| Gas | | | $ | | Yes |
| Water/sewer | | | $ | | Yes |
| Internet | | | $ | | Yes |
| Cable/streaming | | | $ | | Yes |
| Trash | | | $ | | Yes |
| **Cleaning** | | | | | |
| Turnover cleans | | | $ | | Yes |
| Deep clean | | | $ | | Yes |
| Laundry service | | | $ | | Yes |
| **Maintenance** | | | | | |
| Repairs | | | $ | | Yes |
| Supplies/parts | | | $ | | Yes |
| Preventive maintenance | | | $ | | Yes |
| **Consumables** | | | | | |
| Toiletries | | | $ | | Yes |
| Kitchen supplies | | | $ | | Yes |
| Cleaning products | | | $ | | Yes |
| Linens/towels (replacement) | | | $ | | Yes |
| **Software/Services** | | | | | |
| Channel manager | | | $ | | Yes |
| Dynamic pricing tool | | | $ | | Yes |
| Smart lock subscription | | | $ | | Yes |
| Accounting software | | | $ | | Yes |
| **Professional** | | | | | |
| Property management fees | | | $ | | Yes |
| Accounting/bookkeeping | | | $ | | Yes |
| Legal | | | $ | | Yes |
| Permits/licenses | | | $ | | Yes |
| **Marketing** | | | | | |
| Photography | | | $ | | Yes |
| Direct booking website | | | $ | | Yes |
| Advertising | | | $ | | Yes |
| **Other** | | | | | |
| Travel to property | | | $ | | Partial |
| Furnishing/decor | | | $ | | Yes (depreciate if >$2,500) |
| Capital improvements | | | $ | | Depreciate |
| | | | | | |
| **TOTAL EXPENSES** | | | **$** | | |

---

## Template 3: Annual Profit & Loss Summary

---

### [Year] — [Property Name]

| | Amount |
|---|--------|
| **REVENUE** | |
| Gross rental income | $ |
| Cleaning fees collected | $ |
| Other income (late fees, damage claims) | $ |
| **Total Revenue** | **$** |
| | |
| **EXPENSES** | |
| Mortgage/rent | $ |
| HOA/condo fees | $ |
| Property tax | $ |
| Insurance | $ |
| Utilities | $ |
| Cleaning (turnover + deep) | $ |
| Maintenance & repairs | $ |
| Consumables & supplies | $ |
| Software & subscriptions | $ |
| Professional services | $ |
| Marketing | $ |
| Platform fees (Airbnb/VRBO) | $ |
| Travel to property | $ |
| Furnishing & decor | $ |
| Other | $ |
| **Total Expenses** | **$** |
| | |
| **NET OPERATING INCOME** | **$** |
| | |
| **Key Metrics** | |
| Total booked nights | |
| Occupancy rate | % |
| Average nightly rate | $ |
| Revenue per available night (RevPAN) | $ |
| Cost per booked night | $ |
| Profit per booked night | $ |

---

## Template 4: Pricing Strategy Worksheet

Use this to set and adjust your nightly rates by season.

---

### Rate Structure

| Season | Dates | Weeknight Rate | Weekend Rate | Holiday Rate | Min Stay |
|--------|-------|---------------|-------------|-------------|----------|
| **Peak** | [e.g., Jun 15 - Sep 5] | $ | $ | $ | nights |
| **High** | [e.g., Dec 15 - Jan 5, spring break] | $ | $ | $ | nights |
| **Shoulder** | [e.g., Sep - Nov, Apr - Jun 14] | $ | $ | $ | nights |
| **Low** | [e.g., Jan 6 - Mar] | $ | $ | $ | nights |

### Special Event Pricing

| Event | Dates | Rate | Min Stay | Notes |
|-------|-------|------|----------|-------|
| [e.g., Ski season opening] | | $ | | |
| [e.g., Local festival] | | $ | | |
| [e.g., Major holiday] | | $ | | |
| [e.g., Graduation weekend] | | $ | | |

### Competitor Analysis

| Property | Bedrooms | Sleeps | Avg Rate | Occupancy Est. | Amenities | Link |
|----------|----------|--------|----------|----------------|-----------|------|
| [Comp 1] | | | $ | | | |
| [Comp 2] | | | $ | | | |
| [Comp 3] | | | $ | | | |
| [Comp 4] | | | $ | | | |
| **Your property** | | | $ | | | |

### Rate Adjustment Decision Framework

| Factor | Adjust Up | Adjust Down |
|--------|-----------|-------------|
| **Booking pace** | Filling faster than expected | Slower than usual, gaps appearing |
| **Competitor rates** | Comps are priced higher | You're significantly above market |
| **Seasonal demand** | Event or holiday driving demand | Off-season with low search volume |
| **Lead time** | Booking is 60+ days out | Booking is within 7 days (fill gap) |
| **Stay length** | Short stays (1-2 nights) — premium for turnover cost | 7+ night stays — discount for reduced turnover |
| **Reviews** | New 5-star reviews boosting ranking | Below 4.5 avg, need volume to recover |

---

## Tips

- **Track everything from Day 1.** Setting up tracking retroactively is painful. Start a spreadsheet before your first guest checks in.
- **Separate your rental finances from personal finances.** Dedicated bank account and credit card for the property. Your accountant will thank you.
- **Review monthly, not annually.** A monthly P&L review takes 15 minutes and lets you catch problems early — an expense creeping up, occupancy dropping, a rate that needs adjusting.
- **Revenue per Available Night (RevPAN) is your most important metric.** It accounts for both rate and occupancy. A high rate with 40% occupancy loses to a moderate rate with 80% occupancy.
- **Don't compete on price alone.** Amenities, reviews, photos, and listing quality drive bookings more than being $10/night cheaper. Invest in the experience.
- **Keep receipts digitally.** Photo every receipt and file it by month. When tax time comes, everything is already organized.
- **Consult a tax professional.** Short-term rental tax rules are complex (passive vs. active income, depreciation, 14-day rule, state/local taxes). A CPA who specializes in rental properties pays for themselves.
