# Quick-Start Guide

You just bought the Property Operations Toolkit. Here's how to get your rental running like a system, not a side hustle.

---

## New Host? Start Here

If you're setting up your first rental or haven't systematized yet, do these three things:

1. **Set up your turnover checklist** — Open `templates/01-turnover-checklist.md`, customize the Standard Turnover for your property, and give it to your cleaner. This is the single highest-impact template in the kit.

2. **Build your emergency card** — Open `templates/06-emergency-procedures.md` and fill out the Emergency Contact Card. Print it, frame it, and put it in the property before your next guest.

3. **Do a full inventory** — Open `templates/03-inventory-supplies.md` and walk through your property room by room. Document everything. This protects you on insurance claims and helps you notice when things go missing.

That's enough to run a safe, consistent operation. Layer in the rest as you go.

---

## Experienced Host? Level Up

If you're already hosting but want to tighten your systems:

- **Automate your maintenance** — The preventive maintenance schedule (`02`) catches expensive problems before they happen. Block one day per quarter for the property.
- **Know your numbers** — The financial tracker (`04`) turns gut feel into data. If you can't tell me your RevPAN or cost per booked night, start here.
- **Optimize your listing** — Run the listing audit checklist (`05`). Most hosts leave ranking points on the table — unchecked amenity boxes, weak opening lines, stale photos.
- **Use AI for the heavy lifting** — The prompts in `prompts/property-setup.md` can write your listing, build a welcome guide, and analyze your reviews in minutes.

---

## What's in Each File

| File | What it is | When you need it |
|------|-----------|-----------------|
| `01-turnover-checklist.md` | 3 checklists: standard, express, deep clean | Every turnover + quarterly deep clean |
| `02-maintenance-tracker.md` | Preventive schedule + maintenance log + vendor contacts + appliance inventory | Monthly checks + when issues arise |
| `03-inventory-supplies.md` | Full property inventory + consumable par levels + damage report template | Setup, quarterly audits, after each stay |
| `04-financial-tracker.md` | Revenue, expense, P&L, and pricing strategy templates | Monthly review, tax time, rate adjustments |
| `05-listing-optimization.md` | Listing copy framework + audit checklist + photography shot list | Listing creation, quarterly audits |
| `06-emergency-procedures.md` | Emergency contact card + response playbook + relocation plan + safety checklist | Day 1 (print and post) + when things go wrong |
| `prompts/property-setup.md` | 7 AI prompts for listings, welcome guides, pricing, reviews | Setup and optimization |
| `prompts/operations-manager.md` | 8 AI prompts for maintenance, vendors, finances, automations | Ongoing operations and problem-solving |

---

## Using the AI Prompts

The prompt packs work with any AI tool — ChatGPT, Claude, Gemini, or whatever you prefer.

**How to use them:**
1. Open the prompt file
2. Copy the prompt you need
3. Replace the bracketed `[text]` with your property details
4. Paste into your AI tool
5. Edit the output — AI gives you 80%, your local knowledge finishes the job

**Best prompts to start with:**
- `property-setup.md → Prompt 1` (Write a Listing) — builds a complete listing from your property details
- `property-setup.md → Prompt 3` (Welcome Guide) — creates a guest-ready house manual
- `operations-manager.md → Prompt 5` (Automate Operations) — shows you what to automate and which tools to use

---

## Importing into Your Tools

### Google Docs / Word
Copy template content and paste into a new document. The checklists convert cleanly with checkboxes.

### Notion
1. Create a new page and paste — Notion converts markdown automatically
2. The maintenance tracker works great as a Notion database with date properties and status columns
3. The inventory template is ideal as a Notion table with filtering by room

### Google Sheets / Excel
The financial tracker (`04`) and inventory (`03`) work best as spreadsheets:
- One tab per month for expenses
- Annual summary tab with formulas
- Inventory as a sortable table with replacement cost totals

### Hospitable / Guesty / OwnerRez / Your PMS
- Import check-in/checkout messaging from the Guest Communication Kit (companion product)
- Use the turnover checklist as a task template triggered by checkout
- Set up automated maintenance reminders based on the schedule in `02`

---

## The Hosting Operations Calendar

| Frequency | What to do | Template |
|-----------|-----------|----------|
| **Every turnover** | Run standard checklist, restock consumables, photo confirmation | `01`, `03` |
| **Monthly** | Safety device checks, lock batteries, plumbing inspection, review finances | `02`, `04` |
| **Quarterly** | Deep clean, full inventory audit, HVAC filter, listing audit, financial review | `01`, `03`, `02`, `05`, `04` |
| **Seasonally** | HVAC service, exterior maintenance, rate adjustment, photo update | `02`, `04`, `05` |
| **Annually** | Professional services, insurance review, appliance assessment, tax prep | `02`, `04`, `06` |

---

## Common Mistakes to Avoid

1. **No written checklist for your cleaner.** "Clean the place" is not a system. A checklist with photos is a system.

2. **Reactive-only maintenance.** If you only fix things when they break, you'll replace a $5,000 HVAC system instead of paying for a $200 tune-up.

3. **Not tracking finances monthly.** If you only look at your numbers at tax time, you've missed 11 months of decisions you could have made.

4. **Competing on price instead of quality.** Dropping your rate $10 to fill a gap costs you thousands annually. Invest in better photos, listing copy, and amenities instead.

5. **No emergency plan.** The first time a pipe bursts at midnight, you'll wish you had a vendor contact sheet and a response playbook ready to go.
