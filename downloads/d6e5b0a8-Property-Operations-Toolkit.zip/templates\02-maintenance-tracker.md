# Maintenance Schedule & Tracker

Reactive maintenance is expensive. Preventive maintenance keeps your property in guest-ready condition and protects your investment. This tracker gives you a system for both.

---

## Template 1: Preventive Maintenance Schedule

Print this and post it at the property, or load it into your project management tool. Check items off as completed and note the date.

---

### Monthly

| Task | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec |
|------|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| Test smoke detectors and CO detectors | | | | | | | | | | | | |
| Check fire extinguisher gauge | | | | | | | | | | | | |
| Inspect plumbing under sinks for leaks | | | | | | | | | | | | |
| Run water in unused fixtures (prevent dry traps) | | | | | | | | | | | | |
| Clean garbage disposal (ice + citrus) | | | | | | | | | | | | |
| Check caulking in bathrooms | | | | | | | | | | | | |
| Inspect weather stripping on doors/windows | | | | | | | | | | | | |
| Check smart lock batteries | | | | | | | | | | | | |

### Quarterly

| Task | Q1 | Q2 | Q3 | Q4 |
|------|----|----|----|----|
| Replace HVAC filter | | | | |
| Deep clean (see Turnover Checklist Template 3) | | | | |
| Test all GFCI outlets | | | | |
| Inspect exterior — siding, roof visible areas, gutters | | | | |
| Check water heater — flush if due (annually at minimum) | | | | |
| Lubricate door hinges and locks | | | | |
| Inspect and clean dryer vent | | | | |
| Check grout and recaulk where needed | | | | |
| Test garage door safety reverse (if applicable) | | | | |

### Seasonal

| Task | Spring | Fall |
|------|--------|------|
| Service HVAC — professional tune-up | | |
| Clean gutters and downspouts | | |
| Power wash exterior, deck, walkways | Spring | |
| Inspect roof for damage | | Fall |
| Check exterior drainage — water flowing away from foundation | Spring | |
| Winterize outdoor plumbing (if applicable) | | Fall |
| Service hot tub — drain, clean, refill | Spring | Fall |
| Check insulation and seal gaps (pest prevention) | | Fall |
| Aerate lawn / landscape maintenance (if applicable) | Spring | |
| Store/swap seasonal furniture and decor | Spring | Fall |

### Annually

| Task | Month Completed | Notes |
|------|----------------|-------|
| Professional carpet cleaning | | |
| Professional window cleaning | | |
| Water heater flush and inspection | | |
| Dryer vent professional cleaning | | |
| Chimney inspection and cleaning (if applicable) | | |
| Appliance check — age, condition, warranty status | | |
| Paint touch-ups — interior walls and trim | | |
| Mattress inspection — replace if needed (every 5-7 years) | | |
| Insurance review — coverage, rates, claims | | |
| Property tax and license/permit renewal | | |

---

## Template 2: Maintenance Request Log

Use this to track issues reported by guests, cleaners, or your own inspections.

---

| # | Date Reported | Reported By | Issue | Priority | Status | Assigned To | Date Resolved | Cost | Notes |
|---|--------------|-------------|-------|----------|--------|-------------|--------------|------|-------|
| 1 | | | | | | | | | |
| 2 | | | | | | | | | |
| 3 | | | | | | | | | |

**Priority levels:**
- **Emergency** — Guest safety or property damage risk. Handle within hours. (Burst pipe, no heat in winter, gas smell, lock failure)
- **Urgent** — Impacts guest experience significantly. Handle within 24 hours. (Broken appliance, AC out in summer, clogged drain, Wi-Fi down)
- **Standard** — Needs fixing but doesn't ruin the stay. Handle within 1 week. (Squeaky door, loose cabinet handle, cosmetic damage, slow drain)
- **Low** — Cosmetic or preventive. Schedule during next vacancy. (Touch-up paint, furniture replacement, upgrades)

**Status options:** Open → In Progress → Waiting on Parts → Complete

---

## Template 3: Appliance & Systems Inventory

Keep this updated. When something breaks at 10 PM, you don't want to be Googling model numbers.

---

| Item | Brand / Model | Serial Number | Purchase Date | Warranty Expiration | Location | Notes |
|------|--------------|---------------|--------------|--------------------|-----------| ------|
| Refrigerator | | | | | Kitchen | |
| Oven/Range | | | | | Kitchen | |
| Dishwasher | | | | | Kitchen | |
| Microwave | | | | | Kitchen | |
| Washer | | | | | Laundry | |
| Dryer | | | | | Laundry | |
| Water heater | | | | | [Location] | |
| HVAC system | | | | | [Location] | |
| Smart lock | | | | | Front door | |
| Wi-Fi router | | | | | [Location] | |
| TV(s) | | | | | [Room] | |
| Hot tub | | | | | [Location] | |
| Smoke detectors | | | | | [Locations] | |
| CO detectors | | | | | [Locations] | |
| Fire extinguisher(s) | | | | | [Locations] | |
| Garage door opener | | | | | Garage | |

---

## Template 4: Vendor Contact Sheet

Your emergency list. Keep it accessible to you, your co-host, and your property manager.

---

| Service | Company / Name | Phone | Email | Notes |
|---------|---------------|-------|-------|-------|
| **Plumber** | | | | |
| **Electrician** | | | | |
| **HVAC** | | | | |
| **Locksmith** | | | | |
| **Handyman** | | | | |
| **Cleaning team** | | | | |
| **Pest control** | | | | |
| **Landscaping** | | | | |
| **Snow removal** | | | | |
| **Appliance repair** | | | | |
| **Hot tub service** | | | | |
| **Internet provider** | | | | Account #: |
| **Electric utility** | | | | Account #: |
| **Gas utility** | | | | Account #: |
| **Water utility** | | | | Account #: |
| **Insurance agent** | | | | Policy #: |
| **Property manager** | | | | |
| **Emergency (police)** | | | | Non-emergency #: |

---

## Tips

- **Preventive maintenance is cheaper than emergency repairs.** A $200 HVAC tune-up prevents a $5,000 replacement in the middle of peak season.
- **Block maintenance days on your calendar.** If you don't schedule it, it doesn't happen. Block one day per quarter for the property.
- **Keep the vendor sheet at the property.** If you have a co-host or property manager, they need this list as much as you do. Laminate it or keep it in a shared doc.
- **Track costs.** Every maintenance expense is a tax deduction (consult your accountant). The log also helps you budget for capital improvements and calculate your true operating costs.
- **Replace, don't repair (sometimes).** If an appliance is more than 8 years old and the repair costs more than 50% of replacement, replace it. You'll save on future repair calls and improve the guest experience.
- **Guest-reported issues are free inspections.** When a guest reports something, thank them and fix it fast. They just told you about a problem before your next review did.
