# AI Prompts: Property Setup & Optimization

Prompts to set up, improve, and optimize your short-term rental property and listings.

---

## Prompt 1: Write a Listing from Scratch

> I need to write a listing for my short-term rental property. Here's what I know:
>
> - **Property type:** [Condo / House / Cabin / Apartment / Studio]
> - **Location:** [City, State — neighborhood or area name]
> - **Bedrooms/bathrooms:** [X bed / X bath]
> - **Sleeps:** [X guests]
> - **Standout features:** [Hot tub, mountain views, walk to beach, newly renovated, etc.]
> - **Amenities:** [List everything — Wi-Fi, washer/dryer, kitchen, parking, fireplace, etc.]
> - **Nearby attractions:** [Ski resort, downtown, trails, restaurants, beach, etc.]
> - **Target guest:** [Families, couples, remote workers, ski trips, etc.]
> - **Vibe:** [Cozy cabin / Modern luxury / Budget-friendly / Rustic charm]
>
> Write a complete Airbnb/VRBO listing with:
> 1. A compelling title (under 50 characters)
> 2. A 3-line opening that hooks the guest before "Read more"
> 3. Detailed space description room by room
> 4. Guest access section
> 5. Location section with specifics (distances, not "close to everything")
> 6. House rules
>
> Write it so a guest can picture themselves there. Sell the experience, not the square footage.

---

## Prompt 2: Audit and Improve My Existing Listing

> Here's my current listing: [paste your full listing text]
>
> Audit it for:
> - **Hook strength:** Does the first 3 lines make someone want to read more?
> - **Specificity:** Am I being vague anywhere? ("Fully equipped kitchen" vs. actual details)
> - **Missing information:** What would a guest want to know that I haven't mentioned?
> - **Keyword optimization:** Am I using terms guests actually search for?
> - **Competitive positioning:** What could I emphasize that competitors probably aren't?
>
> Rewrite the weakest sections and explain why the changes are stronger.

---

## Prompt 3: Create a Welcome Guide / House Manual

> I need a digital welcome guide for my short-term rental. Here's the property info:
>
> - **Property name/address:** [Details]
> - **Wi-Fi network and password:** [Details]
> - **Check-in instructions:** [Smart lock code, key location, parking spot, etc.]
> - **Check-out instructions:** [What guests should do before leaving]
> - **Thermostat instructions:** [How to operate, suggested settings]
> - **Appliance notes:** [Anything non-obvious — finicky coffee maker, TV input, etc.]
> - **Hot tub/pool/fireplace instructions:** [If applicable]
> - **Trash and recycling:** [Pickup days, where bins are, sorting rules]
> - **Parking:** [Details, assigned spot, street parking rules]
> - **House rules:** [Quiet hours, max occupancy, smoking, pets]
> - **Local recommendations:** [Restaurants, coffee shops, activities, grocery stores]
> - **Emergency contacts:** [Your phone, local emergency numbers, maintenance]
>
> Create a well-organized, friendly welcome guide that covers everything a guest needs without overwhelming them. Group sections logically and keep the tone warm.

---

## Prompt 4: Set Up a Pricing Strategy

> Help me build a pricing strategy for my short-term rental.
>
> - **Property:** [Type, size, location]
> - **Current nightly rate:** $[Amount]
> - **Current occupancy:** [X]%
> - **Peak season:** [When and why]
> - **Low season:** [When]
> - **Local events that drive demand:** [Festivals, ski season, college events, etc.]
> - **Competitor rates:** [What similar properties charge, if known]
> - **My costs per month:** $[Approximate — mortgage, utilities, cleaning, etc.]
>
> Help me:
> 1. Set seasonal rate tiers (peak, high, shoulder, low)
> 2. Determine weekday vs. weekend pricing
> 3. Set minimum stay requirements by season
> 4. Identify dates where I should charge premium rates
> 5. Calculate my break-even occupancy rate
> 6. Recommend whether I should use a dynamic pricing tool (PriceLabs, Wheelhouse, Beyond)

---

## Prompt 5: Analyze My Reviews for Patterns

> Here are my last [X] guest reviews: [paste them all]
>
> Analyze them for:
> 1. **What guests love most** — recurring positive themes
> 2. **What guests complain about** — recurring negative themes or missing expectations
> 3. **Amenity mentions** — which amenities get called out (good or bad)?
> 4. **Comparison language** — do guests compare you to hotels, other rentals, or expectations?
> 5. **Suggestions** — did any guest suggest an improvement?
>
> Then give me:
> - A prioritized list of improvements based on review frequency and impact
> - Suggested responses for any negative reviews (if I haven't responded yet)
> - Language from positive reviews I should use in my listing copy (social proof)

---

## Prompt 6: Create a Property Setup Checklist for a New Listing

> I'm setting up a new short-term rental property and want to make sure I don't miss anything. Here's the situation:
>
> - **Property type:** [Condo / House / etc.]
> - **Location:** [City, State]
> - **Bedrooms/bathrooms:** [X/X]
> - **Target guest:** [Families / Couples / Business travelers / etc.]
> - **Budget for furnishing/setup:** $[Amount]
> - **Platform(s):** [Airbnb / VRBO / Both / Direct booking too]
>
> Create a comprehensive setup checklist covering:
> 1. Legal/permits — what do I need in [city/state]?
> 2. Insurance — what type of coverage do I need?
> 3. Furnishing essentials by room
> 4. Amenities that drive bookings in my market
> 5. Technology setup (smart lock, Wi-Fi, noise monitor, etc.)
> 6. Photography and listing creation
> 7. Pricing and calendar setup
> 8. Automations to set up (messaging, cleaning, pricing)
> 9. First-month operational checklist
>
> Prioritize by what needs to happen before the first booking vs. what can come later.

---

## Prompt 7: Write Responses to Guest Reviews

> I need to respond to these guest reviews. For each one, write a response that's professional, warm, and shows future guests that I'm an attentive host.
>
> **Review 1 (positive):** "[Paste review]"
>
> **Review 2 (mixed — some praise, some criticism):** "[Paste review]"
>
> **Review 3 (negative):** "[Paste review]"
>
> Guidelines:
> - Thank every guest by name
> - For positive reviews: acknowledge specific things they mentioned, invite them back
> - For mixed reviews: thank them for the feedback, acknowledge the issue, explain what you've done to fix it
> - For negative reviews: don't be defensive, take responsibility where appropriate, explain corrective action, keep it brief
> - Every response should make a future guest feel confident booking with me
