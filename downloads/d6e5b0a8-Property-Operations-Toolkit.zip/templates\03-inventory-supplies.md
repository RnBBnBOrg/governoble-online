# Inventory & Supplies Management

Running out of toilet paper mid-stay is a one-star detail in a five-star review. These templates help you track what's in the property, what needs restocking, and what par levels to maintain.

---

## Template 1: Property Inventory — Everything in the Unit

Document every item in the property. Use this for insurance claims, damage assessments, and to ensure nothing walks away.

---

### Kitchen

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Dinner plates | | | | |
| Salad/dessert plates | | | | |
| Bowls | | | | |
| Coffee mugs | | | | |
| Drinking glasses | | | | |
| Wine glasses | | | | |
| Forks | | | | |
| Knives (table) | | | | |
| Spoons | | | | |
| Serving spoons/utensils | | | | |
| Chef's knife | | | | |
| Cutting board(s) | | | | |
| Pots (small, medium, large) | | | | |
| Pans (skillet, sauté) | | | | |
| Baking sheet | | | | |
| Casserole/baking dish | | | | |
| Mixing bowls | | | | |
| Colander | | | | |
| Can opener | | | | |
| Corkscrew/bottle opener | | | | |
| Measuring cups/spoons | | | | |
| Spatula, tongs, whisk | | | | |
| Dish towels | | | | |
| Pot holders/oven mitts | | | | |
| Coffee maker | | | | |
| Toaster | | | | |
| Blender | | | | |
| Trash can | | | | |

### Living / Common Areas

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Sofa | | | | |
| Armchair(s) | | | | |
| Coffee table | | | | |
| Side table(s) | | | | |
| TV | | | | |
| TV remote | | | | |
| Streaming device (Roku, etc.) | | | | |
| Throw pillows | | | | |
| Throw blankets | | | | |
| Lamps | | | | |
| Area rug(s) | | | | |
| Board games / cards | | | | |
| Books | | | | |
| Wall art / decor | | | | |

### Bedrooms (per room: _____________)

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Bed frame | | | | |
| Mattress | | | | Size: |
| Mattress protector | | | | |
| Pillows | | | | |
| Pillow protectors | | | | |
| Sheet sets (on hand) | | | | |
| Duvet/comforter | | | | |
| Duvet cover | | | | |
| Extra blanket | | | | |
| Nightstand(s) | | | | |
| Dresser | | | | |
| Hangers | | | | |
| Lamp(s) | | | | |
| Alarm clock | | | | |
| Phone charger(s) | | | | |

### Bathrooms (per room: _____________)

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Bath towels | | | | |
| Hand towels | | | | |
| Washcloths | | | | |
| Bath mat | | | | |
| Shower curtain + liner | | | | |
| Toilet brush | | | | |
| Plunger | | | | |
| Trash can | | | | |
| Mirror | | | | |
| Towel bar/hooks | | | | |
| Hair dryer | | | | |

### Outdoor (if applicable)

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Patio chairs | | | | |
| Patio table | | | | |
| Grill | | | | |
| Grill tools | | | | |
| Outdoor rug | | | | |
| Fire pit | | | | |
| Hot tub cover | | | | |

### Utility / Storage

| Item | Quantity | Condition | Replacement Cost | Notes |
|------|----------|-----------|-----------------|-------|
| Vacuum | | | | |
| Broom + dustpan | | | | |
| Mop | | | | |
| Iron + ironing board | | | | |
| Tool kit (basic) | | | | |
| First aid kit | | | | |
| Flashlight | | | | |
| Extra batteries | | | | |
| Snow shovel (seasonal) | | | | |

---

## Template 2: Consumable Supplies — Par Levels & Restock List

Set par levels based on your property size and average booking length. Restock to par after every deep clean or when supplies run low.

---

| Supply | Par Level | Current Stock | Reorder? | Brand / Notes |
|--------|-----------|--------------|----------|---------------|
| **Bathroom** | | | | |
| Toilet paper rolls | | | | |
| Hand soap (pump bottles) | | | | |
| Shampoo | | | | |
| Conditioner | | | | |
| Body wash | | | | |
| Lotion | | | | |
| Tissues | | | | |
| **Kitchen** | | | | |
| Dish soap | | | | |
| Dishwasher pods/tabs | | | | |
| Sponges | | | | |
| Paper towels | | | | |
| Trash bags (kitchen) | | | | |
| Trash bags (small/bathroom) | | | | |
| Aluminum foil | | | | |
| Plastic wrap | | | | |
| Zip-lock bags | | | | |
| Coffee (ground/pods) | | | | |
| Coffee filters | | | | |
| Sugar packets | | | | |
| Creamer | | | | |
| Salt and pepper | | | | |
| Cooking oil | | | | |
| **Laundry** | | | | |
| Laundry detergent | | | | |
| Dryer sheets | | | | |
| Stain remover | | | | |
| **Cleaning** | | | | |
| All-purpose cleaner | | | | |
| Glass cleaner | | | | |
| Toilet bowl cleaner | | | | |
| Disinfecting wipes | | | | |
| **Other** | | | | |
| Light bulbs (types: ____) | | | | |
| Batteries (AA, AAA, 9V) | | | | |
| HVAC filters (size: ____) | | | | |
| Smart lock batteries | | | | |
| Propane tank (grill) | | | | |
| Hot tub chemicals | | | | |

---

## Template 3: Post-Checkout Damage & Missing Items Report

Fill this out when the cleaner or you notice damage or missing items during turnover.

---

**Property:** [Name]
**Guest:** [Name]
**Stay dates:** [Check-in] to [Check-out]
**Inspected by:** [Name]
**Inspection date:** [Date]

### Damage Found

| Item / Area | Description of Damage | Photo Taken? | Estimated Repair/Replace Cost | Action |
|-------------|----------------------|-------------|-------------------------------|--------|
| | | Yes / No | $ | |
| | | Yes / No | $ | |
| | | Yes / No | $ | |

### Missing Items

| Item | Last Confirmed Present | Estimated Value | Action |
|------|----------------------|----------------|--------|
| | | $ | |
| | | $ | |

### Resolution

- [ ] No damage — no action needed
- [ ] Minor damage — absorbed as cost of doing business
- [ ] Damage claim filed through [platform] — Claim #: ____
- [ ] Guest contacted directly
- [ ] Security deposit charge processed — Amount: $____
- [ ] Insurance claim filed — Claim #: ____

**Total cost of damage/missing items:** $____

**Notes:**

---

## Tips

- **Do a full inventory when you first furnish the property, then audit quarterly.** Things disappear slowly — a wine glass here, a towel there. Quarterly audits catch it before you're short for a guest.
- **Buy consumables in bulk.** Set up Subscribe & Save or buy from a warehouse club. Your per-unit cost drops and you never run out.
- **Standardize everything.** One brand of towels, one type of sheet, one style of dinnerware. When something breaks, you replace it with an identical match — no mismatched sets.
- **Keep a restock bin at the property.** A labeled bin with backup consumables means your cleaner can restock without a separate supply run.
- **Document damage the same day.** Platforms have deadlines for filing claims (Airbnb gives you 14 days). Photos taken during turnover are your evidence — don't wait.
- **Track replacement costs for taxes.** Every item you replace is a deductible expense. Keep receipts or track them in your maintenance log.
