# Emergency Procedures & Guest Safety

Things go wrong. The difference between a crisis and an inconvenience is having a plan. These templates cover the most common emergencies, how to respond, and how to prepare your property.

---

## Template 1: Emergency Contact Card

Print and frame this. Place one in the welcome binder and one on the refrigerator.

---

### Emergency Information — [Property Name]

**Property address:** [Full address including unit number]

**Emergency services:** 911

**Non-emergency police:** [Local number]
**Poison control:** 1-800-222-1222
**Nearest hospital:** [Name, address, phone, distance]
**Nearest urgent care:** [Name, address, hours, distance]
**Nearest pharmacy:** [Name, address, hours]

**Property owner/manager:** [Name] — [Phone]

**Building management/HOA:** [Name/company] — [Phone]
**After-hours maintenance:** [Number]

**Utilities — emergency shutoff locations:**
- **Water main:** [Location — e.g., "Closet next to water heater" or "Exterior, south side of building"]
- **Gas shutoff:** [Location, if applicable]
- **Electrical panel:** [Location — e.g., "Laundry closet, left wall"]

**Wi-Fi network:** [Network name]
**Wi-Fi password:** [Password]

---

## Template 2: Emergency Response Playbook

Your step-by-step guide for each scenario. Keep this accessible to you, your co-host, and your cleaner.

---

### Water Leak / Burst Pipe

**Severity:** Emergency
**Response time:** Immediately

1. Instruct guest to locate and turn off the water main valve (location noted on emergency card)
2. If unable to locate, instruct them to call building maintenance: [number]
3. Call your plumber: [name, number]
4. If after hours and severe, call emergency plumber: [name, number]
5. Instruct guest to move belongings away from water and place towels to contain spread
6. Document damage with photos — ask guest to send photos immediately
7. If property is uninhabitable, offer to help relocate the guest (see relocation template below)
8. File insurance claim if applicable
9. Contact platform to document the issue

**Prevention:** Annual plumbing inspection. Know your pipe age. Winterize if in a freeze-prone area.

---

### Power Outage

**Severity:** Urgent
**Response time:** Within 1 hour

1. Check if outage is property-specific or area-wide
   - Ask guest to check breaker panel (location on emergency card)
   - Check utility company outage map: [URL]
2. If breaker tripped: instruct guest to flip it back. If it trips again, call electrician
3. If area-wide: provide estimated restoration time (from utility company)
4. Inform guest of flashlight location: [location in property]
5. If outage lasts 4+ hours: check on guest, offer compensation or early checkout option
6. If outage lasts 12+ hours: offer to relocate guest

**Location of flashlight/candles:** [Specify — e.g., "Kitchen drawer next to stove, utility closet"]

---

### No Heat / No AC

**Severity:** Urgent (emergency in extreme temperatures)
**Response time:** Within 2 hours

1. Walk guest through thermostat troubleshooting (check batteries, mode, temp setting)
2. Check HVAC breaker at electrical panel
3. Check filter — clogged filter can shut down the system
4. If unresolved, call HVAC tech: [name, number, after-hours number]
5. Provide temporary solution: space heater location [____] / extra blankets [____] / portable fan [____]
6. If extreme temps and can't resolve same-day: offer relocation

**Prevention:** Bi-annual HVAC service (spring and fall). Replace filters monthly during heavy-use seasons.

---

### Plumbing Clog / Toilet Overflow

**Severity:** Standard to Urgent
**Response time:** Within a few hours

1. Plunger location: [specify]
2. If plunger doesn't resolve: call plumber
3. If overflow: instruct guest to turn off water at the toilet shutoff valve (behind/beside the toilet)
4. Provide extra towels for cleanup
5. Send cleaner for an extra clean if needed
6. Do not charge the guest unless damage was caused by prohibited items

---

### Lock / Key Issue — Guest Locked Out

**Severity:** Urgent
**Response time:** Within 30 minutes

1. If smart lock: reset code remotely, walk guest through re-entry
2. If smart lock battery died: guide guest to use physical key backup (location: ____)
3. If no backup available: call locksmith: [name, number]
4. If late night and no locksmith: provide hotel option and reimburse

**Prevention:** Smart lock with backup key. Check batteries monthly. Always have a second access method.

---

### Wi-Fi Down

**Severity:** Standard
**Response time:** Within 1-2 hours

1. Instruct guest to restart router: unplug, wait 30 seconds, plug back in
2. Router location: [specify]
3. If restart doesn't work: check with ISP for outage: [ISP name, number, account #]
4. If extended outage: offer mobile hotspot or data reimbursement
5. Apologize and offer a small credit toward their stay if it significantly impacts their experience

---

### Noise Complaint (from or about your guest)

**Severity:** Standard
**Response time:** Within 1 hour

1. Contact guest directly — call, don't just message
2. Reference quiet hours in house rules (documented in the listing)
3. If complaint is FROM your guest about external noise: acknowledge, apologize for what you can, offer earplugs/white noise machine location
4. If complaint is ABOUT your guest: single warning, then escalate
5. Document everything on-platform
6. If repeated: contact platform support, consider ending the reservation

---

### Property Damage Discovered During Stay

**Severity:** Varies
**Response time:** Assess same day

1. Ask guest to send photos and describe what happened
2. Assess: accidental vs. negligent vs. malicious
3. Document with photos and written description
4. For minor accidental damage: absorb it, maintain hospitality
5. For significant damage: inform guest you'll need to file a claim
6. File damage claim through platform within the required window
7. File insurance claim if over platform coverage limits

---

## Template 3: Guest Relocation Plan

When the property becomes uninhabitable during a stay.

---

### Relocation Checklist

- [ ] Inform guest immediately — call, don't message
- [ ] Apologize sincerely and take responsibility for solving it
- [ ] Identify alternative accommodation:
  - [ ] Contact partner hosts in your area: [Name/number, Name/number]
  - [ ] Search platform for comparable listings available tonight
  - [ ] Identify nearby hotels as backup: [Hotel name, phone, typical rate]
- [ ] Offer to book and pay for the alternative (don't make the guest do the work)
- [ ] Arrange transportation if needed
- [ ] Refund remaining nights through the platform
- [ ] Cover any price difference for the alternative accommodation
- [ ] Follow up the next day to make sure they're comfortable
- [ ] Send a written apology and any additional compensation (future stay credit, etc.)

### Relocation Message Template

> Hi [Guest Name],
>
> I'm so sorry about this situation. I know this isn't the experience you planned, and I take full responsibility for making it right.
>
> I've [booked / am booking] an alternative place for you at [Property/Hotel Name] for the remainder of your stay. It's [brief description — comparable or better]. I'm covering the cost — you won't pay anything additional.
>
> [If applicable: "I can also arrange transportation / I'll send you the address and check-in details within the next 30 minutes."]
>
> I'll be processing a full refund for your remaining nights here through [platform].
>
> Again, I'm truly sorry. If there's anything else I can do, please don't hesitate to call me directly at [phone].
>
> [Your Name]

---

## Template 4: Property Safety Checklist

Review this quarterly. These items protect your guests and your liability.

---

- [ ] Smoke detectors — tested and batteries replaced (all floors, every bedroom)
- [ ] Carbon monoxide detectors — tested and current (required by law in most states)
- [ ] Fire extinguisher — inspected, accessible, not expired
- [ ] First aid kit — stocked and accessible, location noted in welcome guide
- [ ] Emergency exits — clear, doors operational, pathway unobstructed
- [ ] Exterior lighting — functional at all entry/exit points
- [ ] Handrails — secure on all stairs (interior and exterior)
- [ ] Slip prevention — bath mats in tubs/showers, outdoor mats at entries
- [ ] Pool/hot tub — proper fencing, safety signage, chemical levels tested
- [ ] Gas appliances — no leaks, proper ventilation, CO detectors nearby
- [ ] Electrical — no exposed wiring, GFCIs in wet areas, no overloaded outlets
- [ ] Locks — all exterior doors lock securely, windows lock
- [ ] Emergency numbers — posted visibly in the property
- [ ] Liability insurance — current, adequate coverage for STR use
- [ ] Local permits/licenses — current and displayed if required

---

## Tips

- **The first 15 minutes define the experience.** A fast, empathetic response to an emergency turns a potential 1-star review into a 5-star story about how you went above and beyond.
- **Call, don't message.** For anything urgent or emotional, a phone call is 10x more effective than a text. Your voice conveys empathy that text can't.
- **Over-communicate, under-promise.** "I have someone on the way and they should arrive within 2 hours" is better than "I'll have it fixed soon."
- **Absorb small costs.** A $50 fix that saves a review is the best ROI in the business. Don't nickel-and-dime guests over accidents.
- **Post-emergency follow-up matters.** After the crisis is resolved, check in the next day. That extra touch is what gets mentioned in the review.
- **Review your emergency plan annually.** Vendor numbers change, contacts move on, codes expire. An outdated emergency plan is worse than no plan — it gives false confidence.
