# Property Operations Toolkit

Everything you need to run a short-term rental like a business — turnovers, maintenance, inventory, finances, listings, and emergencies.

## What's Inside

- **6 templates** covering every operational area of property management
- **15 AI prompts** to set up, optimize, and manage your rental property
- **Quick-start guide** with an operations calendar and tool import instructions

## Where to Start

Open `guides/quick-start.md` for a step-by-step walkthrough based on your experience level.

## Folder Structure

```
templates/          — Fill-in-the-blank documents for each operational area
  01-turnover-checklist.md
  02-maintenance-tracker.md
  03-inventory-supplies.md
  04-financial-tracker.md
  05-listing-optimization.md
  06-emergency-procedures.md

prompts/            — Copy-paste AI prompts for any AI tool
  property-setup.md               (7 prompts)
  operations-manager.md            (8 prompts)

guides/             — How to use this toolkit
  quick-start.md
```
