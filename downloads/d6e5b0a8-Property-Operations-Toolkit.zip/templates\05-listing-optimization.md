# Listing Optimization Guide

Your listing is a sales page. It's the only thing standing between a searcher and a booking. These templates help you write listings that convert, photograph your property effectively, and audit your performance.

---

## Template 1: Listing Copy — Section by Section

---

### Title (50 characters max on most platforms)

**Formula:** [Unique Feature] + [Property Type] + [Location/Vibe Keyword]

**Examples:**
- Mountain View Condo | Walk to Ski Lifts
- Modern Loft Downtown | Rooftop Access
- Cozy Cabin | Hot Tub + Fireplace + Creek Views
- Beachfront Studio | Steps to Sand

**Your title:** ________________________________________

---

### Summary / Introduction (first 3 lines visible before "Read more")

This is the only part most guests read. Lead with what makes you different, not what makes you acceptable.

**Framework:**

> [One sentence about the experience — what it feels like to stay here.]
>
> [One sentence about the standout amenity or feature that's hard to find in your market.]
>
> [One sentence about convenience — location, access, or what's nearby.]

**Example:**

> Wake up to mountain views from a king bed and start your day with coffee on the private balcony. This fully updated condo is a 5-minute walk to the ski lifts and comes stocked with everything you need for a hassle-free stay. Downtown Frisco's restaurants, shops, and trails are right outside your door.

---

### The Space

Detail the property room by room. Be specific — vague descriptions don't convert.

**For each area, cover:**
- What's in it (furniture, amenities)
- What makes it notable (view, upgraded, spacious, newly renovated)
- How many it sleeps/serves

**Example format:**

> **Living Room:** Open floor plan with a 55" smart TV (Netflix, Hulu), gas fireplace, and seating for 6. Floor-to-ceiling windows with mountain views.
>
> **Kitchen:** Full kitchen with granite counters, stainless appliances, drip coffee maker, and everything you need to cook a real meal — not just reheat leftovers.
>
> **Primary Bedroom:** King bed with premium mattress, blackout curtains, and an en-suite bathroom with walk-in shower.
>
> **Second Bedroom:** Queen bed, closet with hangers, bedside USB chargers.
>
> **Bathroom:** [Details for each]
>
> **Outdoor Space:** [Balcony/patio/yard details, hot tub if applicable]

---

### Guest Access

What spaces and amenities do guests have access to?

- [ ] Entire property — private, not shared
- [ ] Parking — [type: garage, driveway, street, assigned spot #]
- [ ] Laundry — [in-unit / shared / none]
- [ ] Building amenities — [pool, gym, lobby, elevator, ski locker, etc.]
- [ ] Outdoor spaces — [balcony, patio, yard, fire pit, hot tub]
- [ ] Storage — [ski storage, gear closet, garage]

---

### Location / Neighborhood

Don't just say "great location." Give distances and specifics.

| What | Distance | Travel Time | Notes |
|------|----------|-------------|-------|
| [Major attraction 1] | | walk / drive | |
| [Major attraction 2] | | walk / drive | |
| Grocery store | | | |
| Restaurants/bars | | | |
| Airport | | | |
| Gas station | | | |
| Hospital/urgent care | | | |
| Public transit | | | |

---

### House Rules

Clear rules prevent problems. Vague rules create arguments.

**Standard rules to address:**
- [ ] Check-in time: ____
- [ ] Check-out time: ____
- [ ] Maximum occupancy: ____ guests
- [ ] Quiet hours: ____ to ____
- [ ] Smoking policy: [No smoking anywhere on property / Designated outdoor area only]
- [ ] Pet policy: [No pets / Pets allowed with $X fee and approval]
- [ ] Parking: [Limit, assigned spots, restrictions]
- [ ] Parties/events: [Not permitted / Allowed with prior approval]
- [ ] Shoes: [Remove at door — provide rack/mat]
- [ ] Trash: [Where to put it, pickup schedule if relevant]
- [ ] Hot tub/pool rules: [If applicable — max capacity, hours, cover when done]
- [ ] Fireplace/fire pit: [Usage restrictions, fire bans]

---

## Template 2: Listing Audit Checklist

Review your listing quarterly against this checklist. One weak area can tank your search ranking and conversion.

---

### Photos

- [ ] Professional quality — well-lit, wide-angle, no clutter
- [ ] Cover photo is your best shot (exterior or hero interior)
- [ ] Every room is represented — no mystery rooms
- [ ] Amenity photos — hot tub, view, kitchen, fireplace, bathroom
- [ ] Outdoor spaces photographed in good weather
- [ ] Seasonal photos rotated (snow in winter, green in summer)
- [ ] No photos with personal items, clutter, or dated decor
- [ ] At least 20 photos total
- [ ] Photos match the current state of the property

### Copy

- [ ] Title is compelling and uses keywords guests search for
- [ ] First 3 lines of description sell the experience
- [ ] Every room is described with specifics
- [ ] Amenities are listed individually (not "fully equipped kitchen")
- [ ] Location section gives distances, not just "close to everything"
- [ ] House rules are clear and complete
- [ ] No spelling errors or outdated information
- [ ] Guest access section is filled out

### Settings

- [ ] Calendar is accurate — no phantom availability or stale blocks
- [ ] Pricing is competitive for the season (checked against comps)
- [ ] Minimum stay is set appropriately per season
- [ ] Instant Book is enabled (boosts ranking on most platforms)
- [ ] Cancellation policy is set and appropriate
- [ ] Cleaning fee is listed and reasonable
- [ ] All amenity checkboxes are selected (Wi-Fi, kitchen, parking, etc.)
- [ ] Response rate is above 90%
- [ ] Response time is under 1 hour

### Reviews

- [ ] Overall rating is 4.7+ (target: 4.8+)
- [ ] Responding to all reviews (positive and negative)
- [ ] Recent reviews mention cleanliness, communication, and accuracy
- [ ] No unaddressed negative feedback patterns
- [ ] Actively requesting reviews from happy guests

---

## Template 3: Photography Shot List

Give this to your photographer or use it as a guide when shooting yourself.

---

| Shot | Room/Area | Angle | Notes |
|------|-----------|-------|-------|
| 1 | Exterior / Hero | Front-facing, slightly elevated | Best light, landscaping clean, seasonal |
| 2 | Living room — wide | Corner, showing full room | Stage with throws, pillows, fireplace on |
| 3 | Living room — detail | Close-up of fireplace or view | Warm, inviting |
| 4 | Kitchen — wide | Show counter space, appliances | Clean, styled with fruit bowl or coffee setup |
| 5 | Kitchen — detail | Coffee station or cookware | Lifestyle feel |
| 6 | Primary bedroom — wide | From doorway or corner | Bed made perfectly, nightstands styled |
| 7 | Primary bedroom — detail | Pillows, throw, view from bed | Cozy, aspirational |
| 8 | Second bedroom | Wide angle | Clean, inviting |
| 9 | Bathroom 1 | Wide, showing shower/tub | Towels rolled, toiletries staged |
| 10 | Bathroom — detail | Vanity area | Clean, bright |
| 11 | Outdoor — wide | Balcony/patio with view | Furniture arranged, morning or golden hour light |
| 12 | Outdoor — detail | Hot tub, fire pit, or seating | Aspirational — guest using it mentally |
| 13 | View | Best vantage point | Mountain, water, skyline, whatever your hero view is |
| 14 | Building exterior | If condo/apartment | Show access, parking, curb appeal |
| 15 | Amenity close-ups | Smart TV, game collection, gear | Show what guests actually use |
| 16-20 | Additional | Laundry, closet, unique features | Fill gaps — every space should be represented |

---

## Tips

- **Your first 5 photos determine whether someone clicks.** Treat them like a movie trailer — show the best moments, create desire, leave them wanting more.
- **Write for skimmers.** Most guests spend 30 seconds scanning. Use short paragraphs, bold key amenities, and lead every section with the most important detail.
- **Search like a guest.** Go to Airbnb, search for your market, and look at the top 10 results. What do their titles, photos, and descriptions have in common? That's your standard.
- **Update seasonally.** A listing with snow photos in July (or vice versa) feels stale. Rotate photos and adjust your description to reference the current season.
- **Amenity checkboxes matter for search filters.** If you have Wi-Fi, parking, a washer, a kitchen — check every box. Guests filter by amenities, and unchecked boxes make you invisible.
- **Price is not the problem — perceived value is.** If you're not booking, improve your photos and copy before you drop your rate. A better listing at the same price beats a mediocre listing at a discount.
