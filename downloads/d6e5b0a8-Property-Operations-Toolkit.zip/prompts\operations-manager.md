# AI Prompts: Operations Manager

Prompts for the day-to-day operations of running a rental property — maintenance, vendors, finances, and systems.

---

## Prompt 1: Build a Maintenance Schedule for My Property

> I own a short-term rental and need a preventive maintenance schedule. Here's my property:
>
> - **Property type:** [Condo / House / Cabin]
> - **Age of building:** [X years]
> - **Climate:** [Mountain / Coastal / Desert / Midwest / etc.]
> - **Key systems:** [HVAC type, water heater type, appliance ages]
> - **Amenities requiring maintenance:** [Hot tub, pool, fireplace, deck, etc.]
> - **HOA handles:** [What the HOA covers, if applicable — exterior, roof, snow removal, etc.]
>
> Create a month-by-month maintenance calendar covering:
> 1. Monthly checks (safety devices, plumbing, locks)
> 2. Quarterly tasks (filters, deep clean, inspections)
> 3. Seasonal tasks specific to my climate
> 4. Annual professional services to schedule
>
> For each task, tell me: what to do, how long it takes, whether I can DIY or need a pro, and estimated cost.

---

## Prompt 2: Evaluate and Choose Vendors

> I need to hire a [cleaner / handyman / property manager / HVAC tech / etc.] for my short-term rental in [location].
>
> Help me:
> 1. Write a description of what I need that I can send to potential vendors
> 2. List the questions I should ask during vetting (experience with STRs, availability, rates, insurance, references)
> 3. Create a scoring rubric to compare 3-4 candidates objectively
> 4. Draft a simple service agreement template covering scope, rates, expectations, and termination
> 5. What red flags should I watch for?

---

## Prompt 3: Analyze My Rental Finances

> Here are my numbers for [month / quarter / year]:
>
> **Revenue:**
> - Gross rental income: $[Amount]
> - Cleaning fees collected: $[Amount]
> - Other income: $[Amount]
>
> **Expenses:**
> [List your expenses by category with amounts]
>
> **Occupancy:** [X]% ([Y] nights booked out of [Z] available)
> **Average nightly rate:** $[Amount]
>
> Analyze my numbers:
> 1. What's my net operating income and profit margin?
> 2. What's my RevPAN (revenue per available night) and how does it compare to typical STRs?
> 3. Which expense categories seem high — where could I cut without hurting guest experience?
> 4. What occupancy rate do I need to break even?
> 5. If I raised my rate by $[X]/night, what occupancy could I drop to and still make the same revenue?
> 6. What should I track that I'm not tracking?

---

## Prompt 4: Create a Turnover Operations SOP

> I need to systematize my turnover process so my cleaning team can operate independently. Here's my current setup:
>
> - **Property size:** [Bedrooms / bathrooms]
> - **Average turnovers per month:** [X]
> - **Turnover window:** [X hours between checkout and check-in]
> - **Cleaning team:** [Solo cleaner / Team / Cleaning company]
> - **Laundry setup:** [In-unit / Off-site laundry service / Cleaner handles]
> - **Current pain points:** [What goes wrong — things get missed, takes too long, inconsistent quality, etc.]
>
> Create a complete turnover SOP that includes:
> 1. Step-by-step cleaning checklist by room
> 2. Restocking checklist with par levels
> 3. Quality check process (photos, verification)
> 4. Communication protocol (how to report issues, damage, missing items)
> 5. Time estimates by section
> 6. Emergency procedures (what to do if something's broken, stained, or missing)

---

## Prompt 5: Automate My Operations

> I want to reduce the time I spend managing my rental. Here's what I'm currently doing manually:
>
> [Describe your current workflow — e.g., "I manually send check-in instructions, I text my cleaner after each checkout, I adjust pricing by hand every week, I respond to every inquiry myself"]
>
> - **Platforms I use:** [Airbnb / VRBO / Direct booking]
> - **Tools I currently use:** [List any software, apps, or services]
> - **Budget for new tools:** $[X/month]
> - **Tech comfort level:** [Comfortable / Will learn / Need something simple]
>
> Recommend automations for:
> 1. Guest messaging (check-in instructions, mid-stay, checkout)
> 2. Cleaning coordination (auto-notify after checkout)
> 3. Dynamic pricing
> 4. Review requests
> 5. Calendar syncing across platforms
> 6. Task management and maintenance tracking
>
> For each recommendation: what tool to use, what it costs, how long to set up, and what it replaces.

---

## Prompt 6: Handle a Difficult Operational Situation

> I'm dealing with a situation at my rental property and need advice on how to handle it:
>
> [Describe the situation — e.g., "My cleaner just quit with no notice and I have a guest checking in tomorrow" / "A guest broke the TV and is denying it" / "My HOA is threatening to fine me for short-term renting" / "My property manager is underperforming but I'm locked into a contract" / "I got a 2-star review that I think is unfair"]
>
> Help me:
> 1. What should I do immediately (next 24 hours)?
> 2. What should I do this week to stabilize the situation?
> 3. What should I put in place to prevent this from happening again?
> 4. If I need to communicate with someone (guest, vendor, HOA), draft the message for me

---

## Prompt 7: Plan a Property Refresh or Upgrade

> My rental property needs a refresh. I want to improve the guest experience and justify [higher rates / better reviews / competitive positioning].
>
> - **Current property condition:** [Functional but dated / Good but missing wow factor / Specific rooms need work]
> - **Budget:** $[Amount]
> - **What guests have mentioned:** [Complaints, suggestions, wishlist items from reviews]
> - **Competitor gap:** [What comparable listings have that I don't]
> - **My market:** [Location, guest type, price range]
>
> Help me prioritize:
> 1. What upgrades have the highest ROI for guest satisfaction and nightly rate?
> 2. What can I do for under $500 that makes a noticeable difference?
> 3. What's worth spending $1,000+ on?
> 4. What order should I tackle things in?
> 5. Are there any upgrades that pay for themselves in reduced maintenance or operations cost?
>
> Give me a phased plan I can execute over the next [3 / 6 / 12] months.

---

## Prompt 8: Build a Guest Guidebook for My Area

> I want to create a local area guide for my guests. My property is in [location].
>
> - **Property vibe / target guest:** [Families / Couples / Adventure seekers / Remote workers]
> - **Season:** [Year-round recommendations, or focus on a specific season]
> - **Radius:** [How far should recommendations extend — walking distance, 15-min drive, day trips]
>
> Create a guidebook organized by:
> 1. **Restaurants** — breakfast, lunch, dinner, date night, family-friendly, budget, splurge
> 2. **Coffee & drinks** — coffee shops, breweries, wine bars
> 3. **Activities** — outdoor (hiking, skiing, water sports), indoor (museums, shopping), rainy day options
> 4. **Groceries & essentials** — nearest stores, pharmacy, gas station
> 5. **Hidden gems** — things only locals know about
> 6. **Day trips** — worth the drive within 1-2 hours
>
> For each recommendation, include the name, what it's known for, approximate distance from the property, and any insider tips. Write it in a friendly, personal tone — like a friend giving advice, not a brochure.
>
> Note: I know you may not have current local data. Give me the structure and categories, and I'll fill in the specific recommendations.
