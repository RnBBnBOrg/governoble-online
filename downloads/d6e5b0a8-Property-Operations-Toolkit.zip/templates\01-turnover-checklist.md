# Turnover Checklist

The turnover is the moment of truth. Every guest walks into what they think is a fresh, untouched space — and it's your job to make that true every single time. These checklists ensure nothing gets missed, whether you're doing it yourself or handing it to a cleaner.

---

## Template 1: Standard Turnover — Full Clean

Use this between every guest. Print it, laminate it, or load it into your cleaning team's app.

---

### Before You Start

- [ ] Check for guest belongings left behind — set aside, do not discard
- [ ] Take photos of any damage before cleaning
- [ ] Open all windows for ventilation (weather permitting)
- [ ] Check guest messages for any reported issues

### Kitchen

- [ ] Empty and wipe refrigerator — check all shelves, drawers, freezer
- [ ] Run dishwasher or hand-wash all dishes, put away
- [ ] Wipe all countertops, backsplash, and cabinet fronts
- [ ] Clean microwave inside and out
- [ ] Clean oven/stovetop — check for spills and baked-on food
- [ ] Clean and sanitize sink and faucet
- [ ] Empty trash, replace liner
- [ ] Restock: dish soap, sponge, paper towels, trash bags
- [ ] Wipe small appliances (coffee maker, toaster) — run a clean cycle on coffee maker if needed
- [ ] Check pantry staples: coffee, filters, sugar, salt, pepper, cooking oil
- [ ] Ensure all cookware, utensils, and dishes are present and in good condition

### Living / Common Areas

- [ ] Vacuum all floors and rugs
- [ ] Mop hard floors
- [ ] Dust all surfaces — shelves, tables, entertainment center, windowsills
- [ ] Wipe light switches and door handles
- [ ] Fluff and arrange couch cushions and throw pillows
- [ ] Fold and position throw blankets
- [ ] Clean glass surfaces — mirrors, picture frames, TV screen
- [ ] Check all light bulbs — replace any burnt out
- [ ] Empty trash cans, replace liners
- [ ] Straighten books, games, remotes — arrange neatly
- [ ] Vacuum under furniture and couch cushions

### Bedrooms (repeat for each)

- [ ] Strip all bedding — sheets, pillowcases, duvet cover, mattress protector
- [ ] Inspect mattress and pillows for stains or damage
- [ ] Make bed with fresh linens — hospital corners, smooth finish
- [ ] Dust nightstands, dresser, headboard
- [ ] Empty and wipe nightstand drawers
- [ ] Check closet — empty hangers spaced evenly, shelf clear
- [ ] Vacuum floors, including under bed
- [ ] Wipe light switches and door handles
- [ ] Check alarm clock / charging stations are working

### Bathrooms (repeat for each)

- [ ] Scrub and sanitize toilet — inside, outside, base, behind
- [ ] Clean and sanitize shower/tub — walls, floor, door/curtain, fixtures
- [ ] Clean and sanitize sink, faucet, and counter
- [ ] Clean mirror
- [ ] Wipe cabinet fronts and handles
- [ ] Empty trash, replace liner
- [ ] Restock: toilet paper (2+ rolls), hand soap, shampoo, conditioner, body wash
- [ ] Hang fresh towels — bath towels, hand towels, washcloths (folded or rolled consistently)
- [ ] Check drain for hair — clear if needed
- [ ] Wipe exhaust fan cover
- [ ] Replace bath mat

### Outdoor Spaces (if applicable)

- [ ] Sweep porch/patio/deck
- [ ] Wipe outdoor furniture
- [ ] Empty outdoor trash/ashtrays
- [ ] Check grill — clean grates, check propane level
- [ ] Clear hot tub cover of debris, check chemical levels
- [ ] Bring in any items that may have blown around
- [ ] Check exterior lights

### Final Walkthrough

- [ ] Set thermostat to arrival temperature — [X°F summer / X°F winter]
- [ ] Turn on entry/porch lights
- [ ] Set out welcome materials — guidebook, Wi-Fi card, keys
- [ ] Check all doors and windows are locked (except entry)
- [ ] Turn on any ambient lighting or accent lights
- [ ] Take "ready" photo — send to owner/manager for confirmation
- [ ] Lock up and secure lockbox/smart lock code

---

## Template 2: Express Turnover — Same-Day Quick Clean

Use when you have a tight window between checkout and check-in (under 3 hours). Covers the essentials — schedule a deep clean within the next 48 hours.

---

### Priority Pass (60-90 minutes)

- [ ] Check for guest belongings and damage — photo any issues
- [ ] Strip and remake all beds with fresh linens
- [ ] Replace all towels and bath mats
- [ ] Scrub and sanitize all toilets, sinks, and showers
- [ ] Restock bathroom consumables (TP, soap, shampoo)
- [ ] Wipe kitchen counters, sink, and stovetop
- [ ] Run or empty dishwasher — put away clean dishes
- [ ] Empty all trash cans, replace liners
- [ ] Empty and wipe refrigerator
- [ ] Vacuum high-traffic areas and all hard floors
- [ ] Wipe door handles and light switches
- [ ] Set thermostat, turn on lights
- [ ] Set out welcome materials
- [ ] Final walkthrough — fresh eyes scan

### Flag for Deep Clean

Note anything that was skipped and schedule within 48 hours:
- [ ] Under-furniture vacuum
- [ ] Oven/microwave deep clean
- [ ] Window cleaning
- [ ] Baseboards and vents
- [ ] Outdoor spaces

---

## Template 3: Deep Clean — Monthly / Quarterly

Schedule this between bookings when you have a gap, or at least once per quarter.

---

### Everything in Standard Turnover, Plus:

**Kitchen**
- [ ] Pull out refrigerator — clean behind and underneath
- [ ] Deep clean oven — self-clean cycle or manual scrub
- [ ] Descale coffee maker and kettle
- [ ] Clean behind and under stove
- [ ] Wipe inside all cabinets and drawers
- [ ] Clean range hood and filter

**Living Areas**
- [ ] Shampoo carpets or deep-clean rugs
- [ ] Clean upholstery — spot treat stains
- [ ] Dust ceiling fans and light fixtures
- [ ] Clean baseboards throughout
- [ ] Wash windows inside and out
- [ ] Clean air vents and replace HVAC filter
- [ ] Check smoke detectors and CO detectors — test and replace batteries

**Bedrooms**
- [ ] Rotate or flip mattresses
- [ ] Wash all pillows, mattress protectors, and duvet inserts
- [ ] Clean under all furniture — move pieces if needed
- [ ] Dust top of closet shelves and door frames
- [ ] Check for scuff marks on walls — touch up paint

**Bathrooms**
- [ ] Re-caulk if needed — check tub, shower, and sink edges
- [ ] Deep clean grout lines
- [ ] Descale showerheads — soak in vinegar solution
- [ ] Check under sinks for leaks
- [ ] Replace shower curtain liners

**Exterior**
- [ ] Power wash deck/patio (seasonal)
- [ ] Clean exterior windows
- [ ] Check exterior lighting and replace bulbs
- [ ] Inspect for pest activity — ants, mice, wasps
- [ ] Service hot tub (drain, clean, refill if due)

---

## Tips

- **Laminate the standard checklist and leave it at the property.** Your cleaner should mark it with dry-erase and send you a photo of the completed checklist after every turn.
- **Time your turnovers.** Track how long each one takes so you can set realistic checkout/check-in gaps. Most standard turnovers take 2-4 hours depending on property size.
- **Photo documentation is your insurance.** A "ready" photo after every turnover protects you from damage claims and shows your cleaner takes pride in their work.
- **Don't skip the deep clean.** It's tempting to push it when bookings are back-to-back. Block off one day per quarter — the long-term condition of your property depends on it.
- **Consistency beats perfection.** A checklist that gets followed every time beats a perfect clean that happens occasionally. Systems win.
